import React, { useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import Svg, { Circle, Path, Defs, LinearGradient as SvgGradient, Stop, G } from 'react-native-svg';
import { useApp } from '../lib/AppContext';

// ---------- Progress Ring ----------
export function ProgressRing({
  size = 120,
  strokeWidth = 12,
  progress,
  color,
  trackColor,
  children,
}: {
  size?: number;
  strokeWidth?: number;
  progress: number;
  color: string;
  trackColor?: string;
  children?: React.ReactNode;
}) {
  const { theme } = useApp();
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(progress, 1));
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size}>
        <Circle cx={size / 2} cy={size / 2} r={radius} stroke={trackColor || theme.chartTrack} strokeWidth={strokeWidth} fill="none" />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={circumference * (1 - clamped)}
          strokeLinecap="round"
          rotation={-90}
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
      <View style={{ position: 'absolute', alignItems: 'center', justifyContent: 'center' }}>{children}</View>
    </View>
  );
}

// ---------- Donut Chart ----------
export interface DonutSegment {
  label: string;
  value: number;
  color: string;
}

export function DonutChart({ data, size = 210, strokeWidth = 26, centerTitle, centerValue }: {
  data: DonutSegment[];
  size?: number;
  strokeWidth?: number;
  centerTitle?: string;
  centerValue?: string;
}) {
  const { theme } = useApp();
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  let offset = 0;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size}>
        <G rotation={-90} origin={`${size / 2}, ${size / 2}`}>
          {data.map((seg, i) => {
            const len = (seg.value / total) * circumference;
            const gap = data.length > 1 ? 3 : 0;
            const el = (
              <Circle
                key={i}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                stroke={seg.color}
                strokeWidth={strokeWidth}
                strokeDasharray={`${Math.max(len - gap, 0.5)} ${circumference - Math.max(len - gap, 0.5)}`}
                strokeDashoffset={-offset}
                strokeLinecap="round"
                fill="transparent"
              />
            );
            offset += len;
            return el;
          })}
        </G>
      </Svg>
      <View style={{ position: 'absolute', alignItems: 'center' }}>
        {centerTitle ? <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700' }}>{centerTitle}</Text> : null}
        {centerValue ? <Text style={{ color: theme.text, fontSize: 20, fontWeight: '900', marginTop: 2 }}>{centerValue}</Text> : null}
      </View>
    </View>
  );
}

// ---------- Bar Chart ----------
export function BarChart({ data, height = 150, color, compact }: {
  data: { label: string; value: number; isToday?: boolean }[];
  height?: number;
  color?: string;
  compact?: boolean;
}) {
  const { theme } = useApp();
  const c = color || theme.primary;
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'flex-end', gap: compact ? 4 : 8, paddingVertical: 4 }}>
      {data.map((d, i) => (
        <View key={i} style={{ alignItems: 'center', width: compact ? 20 : 26 }}>
          {d.value > 0 ? (
            <Text style={{ color: theme.textMuted, fontSize: 8.5, fontWeight: '700', marginBottom: 3 }} numberOfLines={1}>
              {d.value >= 1000 ? `${(d.value / 1000).toFixed(1)}k` : Math.round(d.value)}
            </Text>
          ) : (
            <View style={{ height: 12 }} />
          )}
          <View
            style={{
              width: compact ? 10 : 14,
              height: Math.max(4, (d.value / max) * (height - 34)),
              backgroundColor: d.isToday ? theme.gold : c,
              borderRadius: 6,
              opacity: d.value > 0 ? 1 : 0.25,
            }}
          />
          <Text style={{ color: d.isToday ? theme.text : theme.textMuted, fontSize: 9, fontWeight: d.isToday ? '800' : '600', marginTop: 5 }}>
            {d.label}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

// ---------- Trend (area) Chart ----------
export function TrendChart({ series, height = 170, labelEvery = 5 }: {
  series: { day: number; thisMonth: number; lastMonth: number }[];
  height?: number;
  labelEvery?: number;
}) {
  const { theme } = useApp();
  const [width, setWidth] = useState(0);
  const pad = 14;
  const max = Math.max(...series.map((p) => Math.max(p.thisMonth, p.lastMonth)), 1);
  const makePath = (key: 'thisMonth' | 'lastMonth') => {
    if (!width) return '';
    const stepX = (width - pad * 2) / (series.length - 1);
    return series
      .map((p, i) => {
        const x = pad + i * stepX;
        const y = height - pad - (p[key] / max) * (height - pad * 2);
        return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };
  const thisPath = makePath('thisMonth');
  const lastPath = makePath('lastMonth');
  const areaPath = thisPath
    ? `${thisPath} L${pad + (series.length - 1) * ((width - pad * 2) / (series.length - 1))},${height - pad} L${pad},${height - pad} Z`
    : '';
  return (
    <View onLayout={(e) => setWidth(e.nativeEvent.layout.width)}>
      {width > 0 ? (
        <Svg width={width} height={height}>
          <Defs>
            <SvgGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={theme.primary} stopOpacity="0.35" />
              <Stop offset="1" stopColor={theme.primary} stopOpacity="0" />
            </SvgGradient>
          </Defs>
          {[0.25, 0.5, 0.75].map((f) => (
            <Path key={f} d={`M${pad},${height * f} L${width - pad},${height * f}`} stroke={theme.border} strokeWidth={1} strokeDasharray="3 5" />
          ))}
          <Path d={areaPath} fill="url(#areaFill)" />
          <Path d={lastPath} stroke={theme.textMuted} strokeWidth={1.5} strokeDasharray="5 5" fill="none" />
          <Path d={thisPath} stroke={theme.primary} strokeWidth={2.5} fill="none" strokeLinejoin="round" />
        </Svg>
      ) : null}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 6 }}>
        {series.filter((_, i) => i % labelEvery === 0 || i === series.length - 1).map((p, i) => (
          <Text key={i} style={{ color: theme.textMuted, fontSize: 9.5, fontWeight: '600' }}>
            {p.day}
          </Text>
        ))}
      </View>
    </View>
  );
}
