import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, Platform } from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withRepeat, withTiming, withSequence, Easing, cancelAnimation } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../lib/AppContext';

interface SpeechRecognitionResult { [index: number]: { transcript: string; isFinal?: boolean } }
interface SpeechRecognitionEvent { results: SpeechRecognitionResult[] }

export default function VoiceInput({ onTranscript, theme }: { onTranscript: (text: string) => void; theme: any }) {
  const { haptic } = useApp();
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [supported, setSupported] = useState(true);
  const recRef = useRef<any>(null);

  const pulse = useSharedValue(1);
  const glow = useSharedValue(0.4);

  useEffect(() => {
    if (Platform.OS === 'web') {
      const w = window as any;
      setSupported(!!(w.SpeechRecognition || w.webkitSpeechRecognition));
    } else {
      setSupported(false);
    }
  }, []);

  useEffect(() => {
    if (listening) {
      pulse.value = withRepeat(withSequence(withTiming(1.12, { duration: 500, easing: Easing.inOut(Easing.ease) }), withTiming(1, { duration: 500, easing: Easing.inOut(Easing.ease) })), -1, false);
      glow.value = withRepeat(withSequence(withTiming(1, { duration: 700 }), withTiming(0.35, { duration: 700 })), -1, false);
    } else {
      cancelAnimation(pulse);
      cancelAnimation(glow);
      pulse.value = withTiming(1);
      glow.value = withTiming(0.4);
    }
  }, [listening]);

  const ringStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }], opacity: glow.value }));

  const startListening = () => {
    if (Platform.OS !== 'web') return;
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) return;
    try {
      const rec = new SR();
      rec.lang = 'ar-SA';
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.onresult = (e: any) => {
        let finalText = '';
        let interimText = '';
        for (let i = 0; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) finalText += r[0].transcript;
          else interimText += r[0].transcript;
        }
        setTranscript(finalText || interimText);
      };
      rec.onend = () => {
        setListening(false);
        const w2 = window as any;
        const SR2 = w2.SpeechRecognition || w2.webkitSpeechRecognition;
        void SR2;
      };
      rec.onerror = () => setListening(false);
      recRef.current = rec;
      rec.start();
      setListening(true);
      haptic('medium');
    } catch {
      setListening(false);
    }
  };

  const stopListening = () => {
    try {
      recRef.current?.stop();
    } catch {}
    setListening(false);
    haptic('light');
    if (transcript.trim()) onTranscript(transcript.trim());
  };

  const toggle = () => {
    if (listening) stopListening();
    else startListening();
  };

  return (
    <View style={{ alignItems: 'center' }}>
      <TouchableOpacity onPress={supported ? toggle : undefined} activeOpacity={0.85} style={{ alignItems: 'center', justifyContent: 'center' }}>
        <Animated.View
          style={[
            {
              position: 'absolute',
              width: 150,
              height: 150,
              borderRadius: 75,
              backgroundColor: theme.primary,
            },
            ringStyle,
          ]}
        />
        <LinearGradient
          colors={listening ? [theme.danger, '#E5484D'] : [theme.primary, theme.primaryDeep]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            width: 128,
            height: 128,
            borderRadius: 64,
            alignItems: 'center',
            justifyContent: 'center',
            shadowColor: theme.primary,
            shadowOpacity: 0.5,
            shadowRadius: 24,
            shadowOffset: { width: 0, height: 8 },
            elevation: 12,
          }}
        >
          <Ionicons name={listening ? 'stop' : 'mic'} size={52} color="#fff" />
        </LinearGradient>
      </TouchableOpacity>
      <Text style={{ color: theme.text, fontSize: 16, fontWeight: '800', marginTop: 22 }}>
        {listening ? 'أنا أسمعك... تحدث الآن' : 'اضغط للتحدث'}
      </Text>
      <Text style={{ color: theme.textSecondary, fontSize: 13, marginTop: 6, textAlign: 'center', lineHeight: 20 }}>
        {listening
          ? 'قل مثلاً: "صرفت 50 جنيه على الغداء"'
          : supported
            ? 'تحدث بصوتك وسأحوّله لمعاملة تلقائياً'
            : 'الإدخال الصوتي يعمل على متصفح Chrome — جربه على الويب أو استخدم النص الذكي'}
      </Text>
      {transcript ? (
        <View
          style={{
            marginTop: 18,
            backgroundColor: theme.cardAlt,
            borderRadius: 16,
            padding: 14,
            borderWidth: 1,
            borderColor: theme.border,
            maxWidth: '100%',
          }}
        >
          <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '700', textAlign: 'center' }}>"{transcript}"</Text>
        </View>
      ) : null}
    </View>
  );
}
