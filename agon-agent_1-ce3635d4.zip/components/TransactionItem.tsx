import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Transaction } from '../lib/types';
import { getCategory } from '../lib/categories';
import { formatMoney, formatTime } from '../lib/format';
import { useApp } from '../lib/AppContext';

export default function TransactionItem({ tx, onPress }: { tx: Transaction; onPress?: () => void }) {
  const { theme, data } = useApp();
  const cat = getCategory(tx.categoryId);
  const isExp = tx.type === 'expense';
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.card,
        borderRadius: 18,
        padding: 14,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: theme.border,
      }}
    >
      <View
        style={{
          width: 46,
          height: 46,
          borderRadius: 15,
          backgroundColor: cat.color + '22',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={cat.icon} size={21} color={cat.color} />
      </View>
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '800' }} numberOfLines={1}>
          {tx.note || cat.name}
        </Text>
        <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '600', marginTop: 2 }} numberOfLines={1}>
          {cat.name} • {formatTime(tx.date)}
        </Text>
      </View>
      <Text style={{ color: isExp ? theme.danger : theme.success, fontSize: 15, fontWeight: '900' }}>
        {isExp ? '-' : '+'}
        {formatMoney(tx.amount, data.settings.currency)}
      </Text>
    </TouchableOpacity>
  );
}
