import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../lib/AppContext';
import { WEEKDAYS, MONTHS } from '../lib/format';

export default function MiniCalendar({ selected, onSelect }: { selected: Date; onSelect: (d: Date) => void }) {
  const { theme } = useApp();
  const [viewMonth, setViewMonth] = useState(new Date(selected.getFullYear(), selected.getMonth(), 1));

  const year = viewMonth.getFullYear();
  const month = viewMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstWeekday = new Date(year, month, 1).getDay(); // 0 = Sunday

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prevMonth = () => setViewMonth(new Date(year, month - 1, 1));
  const nextMonth = () => setViewMonth(new Date(year, month + 1, 1));

  const isSelected = (day: number) => {
    const s = new Date(selected);
    return s.getFullYear() === year && s.getMonth() === month && s.getDate() === day;
  };

  return (
    <View style={{ backgroundColor: theme.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: theme.border }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <TouchableOpacity onPress={prevMonth} style={{ padding: 6 }}>
          <Ionicons name="chevron-back" size={20} color={theme.text} />
        </TouchableOpacity>
        <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800' }}>
          {MONTHS[month]} {year}
        </Text>
        <TouchableOpacity onPress={nextMonth} style={{ padding: 6 }}>
          <Ionicons name="chevron-forward" size={20} color={theme.text} />
        </TouchableOpacity>
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 8 }}>
        {WEEKDAYS.map((d, i) => (
          <Text key={i} style={{ color: theme.textMuted, fontSize: 11, fontWeight: '700', width: 36, textAlign: 'center' }}>
            {d.slice(0, 5)}
          </Text>
        ))}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {cells.map((day, i) => {
          if (day === null) return <View key={i} style={{ width: 36, height: 38 }} />;
          const sel = isSelected(day);
          return (
            <TouchableOpacity
              key={i}
              onPress={() => onSelect(new Date(year, month, day, 12))}
              style={{
                width: 36,
                height: 38,
                borderRadius: 12,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: sel ? theme.primary : 'transparent',
                margin: 1,
              }}
            >
              <Text style={{ color: sel ? theme.onPrimary : theme.text, fontSize: 13, fontWeight: sel ? '900' : '700' }}>{day}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}
