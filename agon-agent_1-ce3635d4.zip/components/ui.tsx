import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ViewStyle, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';
import { useApp } from '../lib/AppContext';

const APressable = Animated.createAnimatedComponent(Pressable);

// Animated pressable with spring scale + web hover cursor
export function AnimatedPressable({
  children,
  onPress,
  style,
  disabled,
  pressScale = 0.96,
}: {
  children: React.ReactNode;
  onPress?: () => void;
  style?: any;
  disabled?: boolean;
  pressScale?: number;
}) {
  const scale = useSharedValue(1);
  const aStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <APressable
      onPress={onPress}
      disabled={disabled}
      onPressIn={() => {
        scale.value = withSpring(pressScale, { damping: 14, stiffness: 320 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 14, stiffness: 320 });
      }}
      style={[style, aStyle, { cursor: onPress ? 'pointer' : 'default' } as any]}
    >
      {children}
    </APressable>
  );
}

export function Card({ children, style, glow }: { children: React.ReactNode; style?: ViewStyle; glow?: boolean }) {
  const { theme } = useApp();
  return (
    <View
      style={[
        {
          backgroundColor: theme.card,
          borderRadius: 22,
          padding: 18,
          borderWidth: 1,
          borderColor: theme.border,
          shadowColor: theme.shadow,
          shadowOpacity: glow ? 0.25 : 0.08,
          shadowRadius: glow ? 20 : 12,
          shadowOffset: { width: 0, height: glow ? 8 : 4 },
          elevation: glow ? 8 : 2,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const { theme } = useApp();
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 4 }}>
      <Text style={{ color: theme.text, fontSize: 17, fontWeight: '800' }}>{title}</Text>
      {action ? (
        <TouchableOpacity onPress={onAction}>
          <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '700' }}>{action}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export function Chip({ label, active, onPress, color }: { label: string; active?: boolean; onPress?: () => void; color?: string }) {
  const { theme } = useApp();
  const c = color || theme.primary;
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={{
        paddingHorizontal: 14,
        paddingVertical: 8,
        borderRadius: 999,
        backgroundColor: active ? c : theme.cardAlt,
        borderWidth: 1,
        borderColor: active ? c : theme.border,
        marginLeft: 8,
      }}
    >
      <Text style={{ color: active ? theme.onPrimary : theme.textSecondary, fontSize: 13, fontWeight: '700' }}>{label}</Text>
    </TouchableOpacity>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon,
  color,
  disabled,
  small,
  outline,
  gradient,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  color?: string;
  disabled?: boolean;
  small?: boolean;
  outline?: boolean;
  gradient?: string[];
}) {
  const { theme } = useApp();
  const c = color || theme.primary;
  const grad = gradient || [c, c + 'CC'];
  if (outline) {
    return (
      <AnimatedPressable onPress={onPress} disabled={disabled} style={{ opacity: disabled ? 0.4 : 1 }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            paddingVertical: small ? 10 : 15,
            paddingHorizontal: small ? 16 : 24,
            borderRadius: 16,
            borderWidth: 1.5,
            borderColor: c,
          }}
        >
          {icon ? <Ionicons name={icon} size={small ? 16 : 19} color={c} /> : null}
          <Text style={{ color: c, fontSize: small ? 13 : 15, fontWeight: '800' }}>{label}</Text>
        </View>
      </AnimatedPressable>
    );
  }
  return (
    <AnimatedPressable onPress={onPress} disabled={disabled} style={{ opacity: disabled ? 0.45 : 1 }}>
      <LinearGradient
        colors={grad as [string, string, ...string[]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          paddingVertical: small ? 11 : 16,
          paddingHorizontal: small ? 18 : 26,
          borderRadius: 16,
          shadowColor: c,
          shadowOpacity: 0.35,
          shadowRadius: 12,
          shadowOffset: { width: 0, height: 5 },
          elevation: 6,
        }}
      >
        {icon ? <Ionicons name={icon} size={small ? 16 : 19} color={theme.onPrimary} /> : null}
        <Text style={{ color: theme.onPrimary, fontSize: small ? 13 : 15, fontWeight: '800' }}>{label}</Text>
      </LinearGradient>
    </AnimatedPressable>
  );
}

export function IconButton({ name, onPress, color, bg, size = 20 }: { name: keyof typeof Ionicons.glyphMap; onPress: () => void; color?: string; bg?: string; size?: number }) {
  const { theme } = useApp();
  return (
    <AnimatedPressable onPress={onPress} pressScale={0.88}>
      <View
        style={{
          width: 42,
          height: 42,
          borderRadius: 14,
          backgroundColor: bg || theme.cardAlt,
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: 1,
          borderColor: theme.border,
        }}
      >
        <Ionicons name={name} size={size} color={color || theme.text} />
      </View>
    </AnimatedPressable>
  );
}

export function EmptyState({
  icon,
  title,
  message,
  actionLabel,
  onAction,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const { theme } = useApp();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: 24 }}>
      <View
        style={{
          width: 84,
          height: 84,
          borderRadius: 28,
          backgroundColor: theme.primarySoft,
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 18,
        }}
      >
        <Ionicons name={icon} size={38} color={theme.primary} />
      </View>
      <Text style={{ color: theme.text, fontSize: 17, fontWeight: '800', marginBottom: 8, textAlign: 'center' }}>{title}</Text>
      <Text style={{ color: theme.textSecondary, fontSize: 13.5, textAlign: 'center', lineHeight: 21 }}>{message}</Text>
      {actionLabel && onAction ? (
        <View style={{ marginTop: 20 }}>
          <PrimaryButton label={actionLabel} onPress={onAction} small />
        </View>
      ) : null}
    </View>
  );
}

export function TypeBadge({ type }: { type: 'expense' | 'income' }) {
  const { theme } = useApp();
  const isExp = type === 'expense';
  const c = isExp ? theme.danger : theme.success;
  return (
    <View
      style={{
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 999,
        backgroundColor: isExp ? theme.dangerSoft : theme.successSoft,
      }}
    >
      <Text style={{ color: c, fontSize: 11, fontWeight: '800' }}>{isExp ? 'مصروف' : 'دخل'}</Text>
    </View>
  );
}

export function Toggle({ value, onChange, color }: { value: boolean; onChange: (v: boolean) => void; color?: string }) {
  const { theme } = useApp();
  const c = color || theme.primary;
  return (
    <TouchableOpacity
      onPress={() => onChange(!value)}
      activeOpacity={0.8}
      style={{
        width: 50,
        height: 29,
        borderRadius: 999,
        backgroundColor: value ? c : theme.chartTrack,
        justifyContent: 'center',
        paddingHorizontal: 3,
      }}
    >
      <View
        style={{
          width: 23,
          height: 23,
          borderRadius: 12,
          backgroundColor: '#fff',
          alignSelf: value ? 'flex-end' : 'flex-start',
        }}
      />
    </TouchableOpacity>
  );
}
