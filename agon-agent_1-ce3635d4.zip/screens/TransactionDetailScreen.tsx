import React, { useMemo, useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useApp } from '../lib/AppContext';
import { PrimaryButton, Chip } from '../components/ui';
import MiniCalendar from '../components/MiniCalendar';
import { getCategory, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../lib/categories';
import { formatMoney, formatFullDate, formatTime } from '../lib/format';
import { Modal } from 'react-native';

export default function TransactionDetailScreen() {
  const { data, theme, updateTransaction, deleteTransaction, speak, haptic } = useApp();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const tx = data.transactions.find((t) => t.id === route.params?.id);

  const [editing, setEditing] = useState(false);
  const [amount, setAmount] = useState(tx ? String(tx.amount) : '');
  const [note, setNote] = useState(tx?.note || '');
  const [categoryId, setCategoryId] = useState(tx?.categoryId || 'food');
  const [type, setType] = useState<'expense' | 'income'>(tx?.type || 'expense');
  const [date, setDate] = useState(tx ? new Date(tx.date) : new Date());
  const [showCalendar, setShowCalendar] = useState(false);

  const categories = useMemo(() => (type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES), [type]);

  if (!tx) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: theme.textSecondary, fontSize: 15, fontWeight: '700' }}>المعاملة غير موجودة</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 16 }}>
          <Text style={{ color: theme.primary, fontSize: 14, fontWeight: '800' }}>رجوع</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  const cat = getCategory(tx.categoryId);
  const isExp = tx.type === 'expense';

  const save = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return;
    updateTransaction(tx.id, {
      type,
      amount: amt,
      categoryId,
      note: note.trim() || cat.name,
      date: date.toISOString(),
    });
    haptic('success');
    speak('تم تحديث المعاملة');
    setEditing(false);
  };

  const doDelete = () => {
    deleteTransaction(tx.id);
    haptic('medium');
    navigation.goBack();
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14 }}>
          <TouchableOpacity
            onPress={() => (editing ? setEditing(false) : navigation.goBack())}
            style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}
          >
            <Ionicons name={editing ? 'arrow-back' : 'close'} size={20} color={theme.text} />
          </TouchableOpacity>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>{editing ? 'تعديل المعاملة' : 'تفاصيل المعاملة'}</Text>
          {!editing ? (
            <TouchableOpacity
              onPress={() => {
                setAmount(String(tx.amount));
                setNote(tx.note);
                setCategoryId(tx.categoryId);
                setType(tx.type);
                setDate(new Date(tx.date));
                setEditing(true);
              }}
              style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}
            >
              <Ionicons name="create" size={18} color={theme.text} />
            </TouchableOpacity>
          ) : (
            <View style={{ width: 40 }} />
          )}
        </View>

        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
          {/* Hero */}
          <LinearGradient
            colors={[isExp ? theme.danger + '33' : theme.primary + '33', theme.card]}
            style={{ borderRadius: 26, padding: 24, borderWidth: 1, borderColor: theme.border, alignItems: 'center', marginBottom: 16 }}
          >
            <View style={{ width: 64, height: 64, borderRadius: 20, backgroundColor: cat.color + '22', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
              <Ionicons name={cat.icon} size={30} color={cat.color} />
            </View>
            <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800' }}>
              {isExp ? 'مصروف' : 'دخل'} • {cat.name}
            </Text>
            {!editing ? (
              <Text style={{ color: theme.text, fontSize: 36, fontWeight: '900', marginTop: 6 }}>
                {isExp ? '-' : '+'}
                {formatMoney(tx.amount, data.settings.currency)}
              </Text>
            ) : null}
            {editing ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: theme.inputBg, borderRadius: 16, paddingHorizontal: 18, marginTop: 10, borderWidth: 1.5, borderColor: theme.primary, width: '100%' }}>
                <TextInput
                  value={amount}
                  onChangeText={(t) => setAmount(t.replace(/[^0-9.]/g, ''))}
                  keyboardType="decimal-pad"
                  placeholder="0"
                  placeholderTextColor={theme.textMuted}
                  style={{ flex: 1, paddingVertical: 14, color: theme.text, fontSize: 28, fontWeight: '900', textAlign: 'center' }}
                />
                <Text style={{ color: theme.primary, fontSize: 16, fontWeight: '900' }}>ج.م</Text>
              </View>
            ) : null}
            <Text style={{ color: theme.textSecondary, fontSize: 13.5, fontWeight: '700', marginTop: 10, textAlign: 'center' }}>
              {formatFullDate(tx.date)} • {formatTime(tx.date)}
            </Text>
          </LinearGradient>

          {/* Note */}
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>الملاحظة</Text>
          {editing ? (
            <TextInput
              value={note}
              onChangeText={setNote}
              placeholder="ملاحظة المعاملة"
              placeholderTextColor={theme.textMuted}
              style={{ backgroundColor: theme.card, borderRadius: 16, padding: 15, color: theme.text, fontSize: 14.5, fontWeight: '700', borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}
            />
          ) : (
            <View style={{ backgroundColor: theme.card, borderRadius: 16, padding: 15, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
              <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '700' }}>{tx.note || cat.name}</Text>
            </View>
          )}

          {/* Type + Category (editing) */}
          {editing ? (
            <View>
              <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>النوع</Text>
              <View style={{ flexDirection: 'row', backgroundColor: theme.cardAlt, borderRadius: 14, padding: 4, marginBottom: 16 }}>
                {(['expense', 'income'] as const).map((t) => (
                  <TouchableOpacity
                    key={t}
                    onPress={() => {
                      setType(t);
                      setCategoryId(t === 'expense' ? 'food' : 'salary');
                    }}
                    style={{ flex: 1, paddingVertical: 10, borderRadius: 11, backgroundColor: type === t ? (t === 'expense' ? theme.danger : theme.primary) : 'transparent', alignItems: 'center' }}
                  >
                    <Text style={{ color: type === t ? '#fff' : theme.textSecondary, fontSize: 13.5, fontWeight: '800' }}>
                      {t === 'expense' ? 'مصروف' : 'دخل'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>الفئة</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
                {categories.map((c) => (
                  <Chip key={c.id} label={c.name} active={categoryId === c.id} onPress={() => setCategoryId(c.id)} color={c.color} />
                ))}
              </View>

              <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>التاريخ</Text>
              <TouchableOpacity
                onPress={() => setShowCalendar(true)}
                style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: theme.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: theme.border, marginBottom: 20 }}
              >
                <Ionicons name="calendar" size={17} color={theme.primary} />
                <Text style={{ color: theme.text, fontSize: 14, fontWeight: '800', marginLeft: 10 }}>{formatFullDate(date.toISOString())}</Text>
              </TouchableOpacity>

              <PrimaryButton label="حفظ التعديلات" icon="checkmark" onPress={save} />
            </View>
          ) : (
            <View>
              {/* Info rows */}
              <View style={{ backgroundColor: theme.card, borderRadius: 20, padding: 6, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
                {[
                  { icon: 'pricetag' as const, label: 'الفئة', value: cat.name, color: cat.color },
                  { icon: 'calendar' as const, label: 'التاريخ', value: formatFullDate(tx.date), color: theme.blue },
                  { icon: 'time' as const, label: 'الوقت', value: formatTime(tx.date), color: theme.purple },
                  { icon: 'swap-horizontal' as const, label: 'النوع', value: isExp ? 'مصروف' : 'دخل', color: isExp ? theme.danger : theme.primary },
                ].map((r, i) => (
                  <View
                    key={r.label}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      padding: 13,
                      borderTopWidth: i === 0 ? 0 : 1,
                      borderTopColor: theme.border,
                    }}
                  >
                    <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: r.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                      <Ionicons name={r.icon} size={15} color={r.color} />
                    </View>
                    <Text style={{ color: theme.textMuted, fontSize: 13, fontWeight: '700', flex: 1, marginLeft: 10 }}>{r.label}</Text>
                    <Text style={{ color: theme.text, fontSize: 13.5, fontWeight: '800' }}>{r.value}</Text>
                  </View>
                ))}
              </View>

              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <PrimaryButton
                    label="تعديل"
                    icon="create"
                    onPress={() => {
                      setAmount(String(tx.amount));
                      setNote(tx.note);
                      setCategoryId(tx.categoryId);
                      setType(tx.type);
                      setDate(new Date(tx.date));
                      setEditing(true);
                    }}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <PrimaryButton label="حذف" icon="trash" color={theme.danger} onPress={doDelete} />
                </View>
              </View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Calendar modal */}
      <Modal visible={showCalendar} transparent animationType="fade" onRequestClose={() => setShowCalendar(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 }}>
          <MiniCalendar
            selected={date}
            onSelect={(d) => {
              setDate(d);
              setShowCalendar(false);
            }}
          />
          <TouchableOpacity onPress={() => setShowCalendar(false)} style={{ marginTop: 14, alignItems: 'center', padding: 12 }}>
            <Text style={{ color: theme.textSecondary, fontSize: 14, fontWeight: '800' }}>إلغاء</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
