import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation, useRoute } from '@react-navigation/native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  cancelAnimation,
  Easing,
} from 'react-native-reanimated';
import { useApp } from '../lib/AppContext';
import { PrimaryButton, Chip } from '../components/ui';
import MiniCalendar from '../components/MiniCalendar';
import { parseText, ParsedTransaction, SAMPLE_PHRASES } from '../lib/parser';
import { getExpenseCategories, getIncomeCategories, getCategory } from '../lib/categories';
import { formatMoney, formatFullDate } from '../lib/format';
import { RecurringFrequency } from '../lib/types';

export default function AddTransactionScreen() {
  const { data, theme, addTransaction, addRecurring, speak, haptic } = useApp();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();

  const initialType: 'expense' | 'income' = route.params?.type || 'expense';
  const [type, setType] = useState<'expense' | 'income'>(initialType);
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState('food');
  const [date, setDate] = useState(new Date());
  const [note, setNote] = useState('');
  const [recurring, setRecurring] = useState<RecurringFrequency | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);
  const [smartText, setSmartText] = useState('');

  // Voice state
  const [listening, setListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [voiceNotice, setVoiceNotice] = useState<string | null>(null);
  const [autoSave, setAutoSave] = useState<ParsedTransaction | null>(null);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const recRef = useRef<any>(null);
  const timerRef = useRef<any>(null);

  const categories = type === 'expense' ? getExpenseCategories() : getIncomeCategories();

  // Mic pulse animation
  const pulse = useSharedValue(1);
  useEffect(() => {
    if (listening) {
      pulse.value = withRepeat(
        withSequence(
          withTiming(1.18, { duration: 450, easing: Easing.inOut(Easing.ease) }),
          withTiming(1, { duration: 450, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        false
      );
    } else {
      cancelAnimation(pulse);
      pulse.value = withTiming(1);
    }
  }, [listening]);
  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  const commit = (tx: {
    type: 'expense' | 'income';
    amount: number;
    categoryId: string;
    note: string;
    date: Date;
    recurring: RecurringFrequency | null;
  }) => {
    addTransaction({
      type: tx.type,
      amount: tx.amount,
      categoryId: tx.categoryId,
      note: tx.note || getCategory(tx.categoryId).name,
      date: tx.date.toISOString(),
    });
    if (tx.recurring) {
      const next = new Date(tx.date);
      if (tx.recurring === 'daily') next.setDate(next.getDate() + 1);
      else if (tx.recurring === 'weekly') next.setDate(next.getDate() + 7);
      else next.setMonth(next.getMonth() + 1);
      addRecurring({
        type: tx.type,
        amount: tx.amount,
        categoryId: tx.categoryId,
        note: tx.note || getCategory(tx.categoryId).name,
        frequency: tx.recurring,
        nextDate: next.toISOString(),
        active: true,
      });
    }
  };

  const saveManual = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return;
    commit({ type, amount: amt, categoryId, note, date, recurring });
    haptic('success');
    speak(`تمت إضافة ${type === 'expense' ? 'مصروف' : 'دخل'} بقيمة ${Math.round(amt)} جنيه على ${getCategory(categoryId).name}`);
    navigation.goBack();
  };

  // ---------- Voice ----------
  const applyParsed = (p: ParsedTransaction) => {
    setType(p.type);
    if (p.amount) setAmount(String(p.amount));
    if (p.categoryId) setCategoryId(p.categoryId);
    if (p.note) setNote(p.note);
    setDate(p.date);
    haptic('medium');
  };

  const commitFromParsed = (p: ParsedTransaction) => {
    if (!p.amount) return;
    commit({
      type: p.type,
      amount: p.amount,
      categoryId: p.categoryId || 'other_expense',
      note: p.note || '',
      date: p.date,
      recurring: null,
    });
    const cat = getCategory(p.categoryId || 'other_expense').name;
    setLastAdded(`${p.type === 'expense' ? 'مصروف' : 'دخل'} ${Math.round(p.amount)} جنيه — ${cat}`);
    speak(`تمت إضافة ${p.type === 'expense' ? 'مصروف' : 'دخل'} بقيمة ${Math.round(p.amount)} جنيه`);
    haptic('success');
    setTimeout(() => setLastAdded(null), 3000);
  };

  const onVoiceFinal = (text: string) => {
    const p = parseText(text);
    applyParsed(p);
    if (p.amount) {
      // auto-save countdown (cancellable)
      setAutoSave(p);
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        commitFromParsed(p);
        setAutoSave(null);
      }, 1800);
    }
  };

  const cancelAutoSave = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setAutoSave(null);
  };

  const startVoice = () => {
    if (Platform.OS !== 'web') {
      setVoiceNotice('التسجيل الصوتي متاح على متصفح Chrome من الويب');
      return;
    }
    const w = window as any;
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) {
      setVoiceNotice('متصفحك لا يدعم التسجيل الصوتي — استخدم Chrome');
      return;
    }
    try {
      const rec = new SR();
      rec.lang = 'ar-SA';
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.onresult = (e: any) => {
        let finalText = '';
        let interimText = '';
        for (let i = 0; i < e.results.length; i++) {
          if (e.results[i].isFinal) finalText += e.results[i][0].transcript;
          else interimText += e.results[i][0].transcript;
        }
        const t = finalText || interimText;
        setLiveTranscript(t);
        if (finalText) onVoiceFinal(finalText);
      };
      rec.onend = () => setListening(false);
      rec.onerror = () => setListening(false);
      recRef.current = rec;
      rec.start();
      setListening(true);
      setVoiceNotice(null);
      haptic('medium');
    } catch {
      setVoiceNotice('حدث خطأ في التسجيل الصوتي');
    }
  };

  const stopVoice = () => {
    try {
      recRef.current?.stop();
    } catch {}
    setListening(false);
  };

  const toggleVoice = () => {
    if (listening) stopVoice();
    else startVoice();
  };

  // Smart text (كتابة) — same auto-fill behavior
  const onSmartSubmit = () => {
    if (!smartText.trim()) return;
    const p = parseText(smartText);
    applyParsed(p);
    if (p.amount) commitFromParsed(p);
    setSmartText('');
  };

  const dateQuickChips = [
    { label: 'اليوم', days: 0 },
    { label: 'أمس', days: 1 },
    { label: 'قبل يومين', days: 2 },
  ];

  const parsedPreview = useMemo(() => (smartText.trim() ? parseText(smartText) : null), [smartText]);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14 }}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}
          >
            <Ionicons name="close" size={20} color={theme.text} />
          </TouchableOpacity>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>معاملة جديدة</Text>
          <TouchableOpacity
            onPress={() => { setAmount(''); setNote(''); setCategoryId(type === 'expense' ? 'food' : 'salary'); setRecurring(null); }}
            style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}
          >
            <Ionicons name="refresh" size={18} color={theme.text} />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {/* Type toggle */}
          <View style={{ flexDirection: 'row', backgroundColor: theme.cardAlt, borderRadius: 16, padding: 4, marginBottom: 14, borderWidth: 1, borderColor: theme.border }}>
            {(['expense', 'income'] as const).map((t) => {
              const c = t === 'expense' ? theme.danger : theme.success;
              return (
                <TouchableOpacity
                  key={t}
                  onPress={() => {
                    setType(t);
                    setCategoryId(t === 'expense' ? 'food' : 'salary');
                  }}
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 6,
                    paddingVertical: 12,
                    borderRadius: 13,
                    backgroundColor: type === t ? c : 'transparent',
                  }}
                >
                  <Ionicons name={t === 'expense' ? 'arrow-up' : 'arrow-down'} size={15} color={type === t ? '#fff' : c} />
                  <Text style={{ color: type === t ? '#fff' : c, fontSize: 14, fontWeight: '800' }}>
                    {t === 'expense' ? 'مصروف' : 'دخل'}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Amount + Mic card */}
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 20, borderWidth: 1, borderColor: theme.border, marginBottom: 14 }}>
            <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 6, textAlign: 'center' }}>
              {type === 'expense' ? 'كم صرفت؟' : 'كم استلمت؟'}
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <TextInput
                value={amount}
                onChangeText={(t) => setAmount(t.replace(/[^0-9.]/g, ''))}
                placeholder="0"
                placeholderTextColor={theme.textMuted}
                keyboardType="decimal-pad"
                style={{ color: theme.text, fontSize: 42, fontWeight: '900', minWidth: 120, textAlign: 'center', padding: 0 }}
              />
              <Text style={{ color: theme.primary, fontSize: 18, fontWeight: '900' }}>
                {data.settings.currency === 'EGP' ? 'ج.م' : data.settings.currency}
              </Text>
            </View>

            {/* Mic button — same place as manual entry */}
            <View style={{ alignItems: 'center', marginTop: 18 }}>
              <TouchableOpacity onPress={toggleVoice} activeOpacity={0.85}>
                <Animated.View style={[{ position: 'absolute', width: 76, height: 76, borderRadius: 38, backgroundColor: theme.primary, opacity: 0.35, top: 0, left: 0 }, pulseStyle]} />
                <LinearGradient
                  colors={listening ? theme.grad.danger as [string, string, ...string[]] : theme.grad.primary as [string, string, ...string[]]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{
                    width: 76,
                    height: 76,
                    borderRadius: 38,
                    alignItems: 'center',
                    justifyContent: 'center',
                    shadowColor: theme.primary,
                    shadowOpacity: 0.4,
                    shadowRadius: 16,
                    shadowOffset: { width: 0, height: 6 },
                    elevation: 8,
                  }}
                >
                  <Ionicons name={listening ? 'stop' : 'mic'} size={32} color="#fff" />
                </LinearGradient>
              </TouchableOpacity>
              <Text style={{ color: theme.text, fontSize: 13.5, fontWeight: '800', marginTop: 12 }}>
                {listening ? 'أنا أسمعك... تحدث الآن' : 'اضغط وتحدث'}
              </Text>
              <Text style={{ color: theme.textMuted, fontSize: 11.5, fontWeight: '600', marginTop: 3, textAlign: 'center' }}>
                {listening ? 'مثال: "صرفت 50 جنيه على الغداء"' : 'قل معاملتك وسأملأ الحقول تلقائياً'}
              </Text>
            </View>

            {/* Live transcript */}
            {liveTranscript ? (
              <View style={{ marginTop: 14, backgroundColor: theme.primarySoft, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: theme.primary + '44' }}>
                <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '700', textAlign: 'center' }}>"{liveTranscript}"</Text>
              </View>
            ) : null}

            {/* Auto-save countdown */}
            {autoSave ? (
              <View style={{ marginTop: 12, flexDirection: 'row', alignItems: 'center', backgroundColor: theme.goldSoft, borderRadius: 14, padding: 12, borderWidth: 1, borderColor: theme.gold + '55' }}>
                <Ionicons name="sparkles" size={16} color={theme.gold} />
                <Text style={{ color: theme.text, fontSize: 12.5, fontWeight: '800', flex: 1, marginLeft: 8 }}>
                  ستتم الإضافة تلقائياً خلال ثوانٍ...
                </Text>
                <TouchableOpacity onPress={cancelAutoSave} style={{ backgroundColor: theme.cardAlt, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 6 }}>
                  <Text style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '800' }}>إلغاء</Text>
                </TouchableOpacity>
              </View>
            ) : null}

            {/* Last added confirmation */}
            {lastAdded ? (
              <View style={{ marginTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: theme.primarySoft, borderRadius: 14, padding: 10, borderWidth: 1, borderColor: theme.primary + '44' }}>
                <Ionicons name="checkmark-circle" size={16} color={theme.primary} />
                <Text style={{ color: theme.primary, fontSize: 12.5, fontWeight: '800', marginLeft: 6 }}>تمت الإضافة: {lastAdded}</Text>
              </View>
            ) : null}

            {voiceNotice ? (
              <View style={{ marginTop: 12, backgroundColor: theme.goldSoft, borderRadius: 12, padding: 10 }}>
                <Text style={{ color: theme.gold, fontSize: 12, fontWeight: '700', textAlign: 'center' }}>{voiceNotice}</Text>
              </View>
            ) : null}
          </View>

          {/* Smart text (كتابة) — same auto-fill */}
          <View style={{ backgroundColor: theme.card, borderRadius: 20, padding: 14, borderWidth: 1, borderColor: theme.border, marginBottom: 14 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <Ionicons name="sparkles" size={14} color={theme.primary} />
              <Text style={{ color: theme.text, fontSize: 13, fontWeight: '900' }}>أو اكتب معاملتك</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <TextInput
                value={smartText}
                onChangeText={setSmartText}
                onSubmitEditing={onSmartSubmit}
                placeholder="مثال: صرفت 50 جنيه على الغداء"
                placeholderTextColor={theme.textMuted}
                style={{ flex: 1, backgroundColor: theme.inputBg, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 11, color: theme.text, fontSize: 13.5, fontWeight: '700', borderWidth: 1, borderColor: theme.border }}
              />
              <TouchableOpacity
                onPress={onSmartSubmit}
                disabled={!smartText.trim()}
                style={{ width: 44, borderRadius: 13, backgroundColor: smartText.trim() ? theme.primary : theme.chartTrack, alignItems: 'center', justifyContent: 'center', opacity: smartText.trim() ? 1 : 0.5 }}
              >
                <Ionicons name="arrow-back" size={18} color={theme.onPrimary} />
              </TouchableOpacity>
            </View>
            {parsedPreview ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>
                <View style={{ backgroundColor: theme.primarySoft, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
                  <Text style={{ color: theme.primary, fontSize: 11, fontWeight: '800' }}>{parsedPreview.type === 'expense' ? 'مصروف' : 'دخل'}</Text>
                </View>
            {parsedPreview.amount ? (
              <View style={{ backgroundColor: theme.dangerSoft, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
                <Text style={{ color: theme.danger, fontSize: 11, fontWeight: '800' }}>{formatMoney(parsedPreview.amount, data.settings.currency)}</Text>
              </View>
            ) : null}
                {parsedPreview.categoryId ? (
                  <View style={{ backgroundColor: theme.primarySoft, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
                    <Text style={{ color: theme.primary, fontSize: 11, fontWeight: '800' }}>{getCategory(parsedPreview.categoryId).name}</Text>
                  </View>
                ) : null}
              </View>
            ) : null}
          </View>

          {/* Category grid */}
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>الفئة</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
            {categories.map((c) => {
              const active = categoryId === c.id;
              return (
                <TouchableOpacity
                  key={c.id}
                  onPress={() => setCategoryId(c.id)}
                  style={{
                    width: '31%',
                    flexGrow: 1,
                    backgroundColor: active ? c.color + '26' : theme.card,
                    borderRadius: 16,
                    paddingVertical: 12,
                    alignItems: 'center',
                    borderWidth: 1.5,
                    borderColor: active ? c.color : theme.border,
                  }}
                >
                  <Ionicons name={c.icon} size={20} color={c.color} />
                  <Text style={{ color: active ? theme.text : theme.textSecondary, fontSize: 11, fontWeight: '800', marginTop: 6, textAlign: 'center' }}>
                    {c.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Date */}
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>التاريخ</Text>
          <View style={{ flexDirection: 'row', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
            {dateQuickChips.map((c) => {
              const d = new Date();
              d.setDate(d.getDate() - c.days);
              const active = date.toDateString() === d.toDateString();
              return (
                <Chip key={c.label} label={c.label} active={active} onPress={() => setDate(new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12))} />
              );
            })}
            <Chip label="اختر تاريخ" active={false} onPress={() => setShowCalendar(true)} />
          </View>
          <Text style={{ color: theme.textSecondary, fontSize: 12.5, fontWeight: '700', marginBottom: 16 }}>
            {formatFullDate(date.toISOString())}
          </Text>

          {/* Note */}
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>ملاحظة (اختياري)</Text>
          <TextInput
            value={note}
            onChangeText={setNote}
            placeholder="مثلاً: غداء مع الزملاء"
            placeholderTextColor={theme.textMuted}
            style={{ backgroundColor: theme.card, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 14, color: theme.text, fontSize: 14, fontWeight: '700', borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}
          />

          {/* Recurring */}
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 8 }}>تكرار المعاملة</Text>
          <View style={{ flexDirection: 'row', gap: 8, marginBottom: 22, flexWrap: 'wrap' }}>
            {([null, 'daily', 'weekly', 'monthly'] as const).map((r) => (
              <Chip key={String(r)} label={r === null ? 'لا يتكرر' : r === 'daily' ? 'يومي' : r === 'weekly' ? 'أسبوعي' : 'شهري'} active={recurring === r} onPress={() => setRecurring(r)} />
            ))}
          </View>

          <PrimaryButton label="حفظ المعاملة" icon="checkmark-circle" onPress={saveManual} disabled={!amount || parseFloat(amount) <= 0} />

          {/* Sample phrases hint */}
          <View style={{ marginTop: 16, backgroundColor: theme.card, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: theme.border }}>
            <Text style={{ color: theme.textMuted, fontSize: 11.5, fontWeight: '800', marginBottom: 6 }}>جرّب قول أو كتابة:</Text>
            {SAMPLE_PHRASES.slice(0, 4).map((s) => (
              <Text key={s} style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '600', marginBottom: 3 }}>
                • {s}
              </Text>
            ))}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Calendar modal */}
      <Modal visible={showCalendar} transparent animationType="fade" onRequestClose={() => setShowCalendar(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 24 }}>
          <MiniCalendar
            selected={date}
            onSelect={(d) => {
              setDate(d);
              setShowCalendar(false);
            }}
          />
          <TouchableOpacity onPress={() => setShowCalendar(false)} style={{ marginTop: 14, alignItems: 'center', padding: 12 }}>
            <Text style={{ color: theme.textSecondary, fontSize: 14, fontWeight: '800' }}>إلغاء</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
