import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/AppContext';
import { Card, SectionTitle, PrimaryButton, AnimatedPressable } from '../components/ui';
import { ProgressRing, BarChart } from '../components/charts';
import TransactionItem from '../components/TransactionItem';
import { getTotals, getWeekSeries, generateInsights, getCategoryBreakdown, getMonthTransactions } from '../lib/analytics';
import { formatMoney, greeting, formatFullDate, formatMonthYear } from '../lib/format';
import { getCategory } from '../lib/categories';

export default function HomeScreen() {
  const { data, theme, speak } = useApp();
  const navigation = useNavigation<any>();
  const [refreshing, setRefreshing] = useState(false);
  const now = new Date();

  const monthTx = useMemo(() => getMonthTransactions(data.transactions, now), [data.transactions]);
  const totals = useMemo(() => getTotals(monthTx), [monthTx]);
  const balance = useMemo(() => getTotals(data.transactions).net, [data.transactions]);
  const week = useMemo(() => getWeekSeries(data.transactions), [data.transactions]);
  const insights = useMemo(
    () => generateInsights(data.transactions, data.budgets, data.goals, data.settings.currency),
    [data.transactions, data.budgets, data.goals]
  );
  const topInsight = insights[0];
  const recent = data.transactions.slice(0, 6);

  const overallBudget = data.budgets.find((b) => b.categoryId === 'overall');
  const budgetLimit = overallBudget?.limit || data.settings.budgetOverall || 1;
  const spentPct = totals.expense / budgetLimit;
  const remaining = budgetLimit - totals.expense;

  const topCat = useMemo(() => getCategoryBreakdown(monthTx, 'expense')[0], [monthTx]);
  const topCatObj = topCat ? getCategory(topCat.categoryId) : null;

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 700);
  };

  const quickActions = [
    { icon: 'add-circle' as const, label: 'مصروف\nسريع', color: '#FF3B30', onPress: () => navigation.navigate('AddTransaction', { type: 'expense' }) },
    { icon: 'arrow-down-circle' as const, label: 'دخل\nسريع', color: '#16A34A', onPress: () => navigation.navigate('AddTransaction', { type: 'income' }) },
    { icon: 'mic' as const, label: 'إدخال\nصوتي', color: '#5A2D91', onPress: () => navigation.navigate('AddTransaction', { voice: true }) },
    { icon: 'analytics' as const, label: 'تحليل\nشامل', color: '#0467A3', onPress: () => navigation.navigate('AnalyticsTab') },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: 130 }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
      >
        {/* Header */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
          <View>
            <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '700' }}>
              {formatFullDate(new Date().toISOString())}
            </Text>
            <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 3 }}>
              {greeting()}، {data.settings.name}
            </Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <TouchableOpacity
              onPress={() => speak(`مرحباً ${data.settings.name}. رصيدك الحالي ${Math.round(balance)} جنيه. مصروفاتك هذا الشهر ${Math.round(totals.expense)} جنيه.`)}
              style={{
                width: 42,
                height: 42,
                borderRadius: 14,
                backgroundColor: theme.cardAlt,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                borderColor: theme.border,
              }}
            >
              <Ionicons name="volume-high" size={19} color={theme.primary} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => navigation.navigate('Settings')}
              style={{
                width: 42,
                height: 42,
                borderRadius: 14,
                backgroundColor: theme.cardAlt,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 1,
                borderColor: theme.border,
              }}
            >
              <Ionicons name="settings" size={19} color={theme.text} />
            </TouchableOpacity>
            <View
              style={{
                width: 42,
                height: 42,
                borderRadius: 14,
                backgroundColor: theme.primarySoft,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ color: theme.primary, fontSize: 17, fontWeight: '900' }}>
                {data.settings.name.slice(0, 1)}
              </Text>
            </View>
          </View>
        </View>

        {/* Hero balance card */}
        <LinearGradient
          colors={theme.grad.primary as [string, string, ...string[]]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1.2 }}
          style={{ borderRadius: 26, padding: 22, marginBottom: 16, overflow: 'hidden' }}
        >
          <View style={{ position: 'absolute', top: -40, left: -40, width: 160, height: 160, borderRadius: 80, backgroundColor: 'rgba(255,255,255,0.08)' }} />
          <View style={{ position: 'absolute', bottom: -60, right: -30, width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(255,255,255,0.06)' }} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View>
              <Text style={{ color: 'rgba(255,255,255,0.75)', fontSize: 13, fontWeight: '700' }}>إجمالي الرصيد</Text>
              <Text style={{ color: '#fff', fontSize: 34, fontWeight: '900', marginTop: 4 }}>
                {Math.round(balance).toLocaleString('en-US')}
                <Text style={{ fontSize: 16, fontWeight: '800' }}> {data.settings.currency === 'EGP' ? 'ج.م' : ''}</Text>
              </Text>
            </View>
            <View style={{ width: 48, height: 48, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="wallet" size={24} color="#fff" />
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 18 }}>
            <View style={{ flex: 1, backgroundColor: 'rgba(34,197,94,0.25)', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="arrow-down" size={13} color="#4ADE80" />
                <Text style={{ color: 'rgba(255,255,255,0.85)', fontSize: 11.5, fontWeight: '700' }}>دخل هذا الشهر</Text>
              </View>
              <Text style={{ color: '#4ADE80', fontSize: 16, fontWeight: '900', marginTop: 4 }}>
                {Math.round(totals.income).toLocaleString('en-US')}
              </Text>
            </View>
            <View style={{ flex: 1, backgroundColor: 'rgba(255,59,48,0.22)', borderRadius: 14, padding: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="arrow-up" size={13} color="#FF6B66" />
                <Text style={{ color: 'rgba(255,255,255,0.85)', fontSize: 11.5, fontWeight: '700' }}>مصروف هذا الشهر</Text>
              </View>
              <Text style={{ color: '#FF6B66', fontSize: 16, fontWeight: '900', marginTop: 4 }}>
                {Math.round(totals.expense).toLocaleString('en-US')}
              </Text>
            </View>
          </View>
        </LinearGradient>

        {/* Budget ring + quick stats */}
        <View style={{ flexDirection: 'row', gap: 12, marginBottom: 16 }}>
          <LinearGradient
            colors={[theme.card, theme.cardAlt]}
            style={{ flex: 1.1, borderRadius: 22, padding: 16, alignItems: 'center', borderWidth: 1, borderColor: theme.border }}
          >
            <ProgressRing
              size={118}
              strokeWidth={12}
              progress={Math.min(spentPct, 1)}
              color={spentPct > 0.9 ? theme.danger : theme.primary}
            >
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900' }}>{Math.round(spentPct * 100)}%</Text>
              <Text style={{ color: theme.textMuted, fontSize: 10.5, fontWeight: '700' }}>من الميزانية</Text>
            </ProgressRing>
            <Text style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '700', marginTop: 10, textAlign: 'center' }}>
              {remaining >= 0 ? `متبقي ${Math.round(remaining).toLocaleString('en-US')} ج.م` : `تجاوزت بـ ${Math.round(-remaining).toLocaleString('en-US')} ج.م`}
            </Text>
          </LinearGradient>

          <View style={{ flex: 1, gap: 10 }}>
            {[  
              { icon: 'calendar' as const, label: 'متوسط يومي', value: `${Math.round(totals.expense / Math.max(now.getDate(), 1)).toLocaleString('en-US')} ج.م`, color: '#0467A3' },
              { icon: 'pricetag' as const, label: 'أعلى فئة', value: topCatObj ? topCatObj.name : '—', color: '#FF6A13' },
              { icon: 'swap-horizontal' as const, label: 'معاملات الشهر', value: `${monthTx.length}`, color: '#5A2D91' },
            ].map((s) => (
              <View
                key={s.label}
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: theme.card,
                  borderRadius: 16,
                  padding: 12,
                  borderWidth: 1,
                  borderColor: theme.border,
                  gap: 10,
                }}
              >
                <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: s.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={s.icon} size={16} color={s.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.textMuted, fontSize: 10.5, fontWeight: '700' }}>{s.label}</Text>
                  <Text style={{ color: theme.text, fontSize: 13, fontWeight: '900', marginTop: 1 }} numberOfLines={1}>
                    {s.value}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Quick actions */}
        <View style={{ flexDirection: 'row', gap: 10, marginBottom: 18 }}>
          {quickActions.map((a) => (
            <AnimatedPressable
              key={a.label}
              onPress={a.onPress}
              style={{
                flex: 1,
                backgroundColor: theme.card,
                borderRadius: 18,
                paddingVertical: 14,
                alignItems: 'center',
                borderWidth: 1,
                borderColor: theme.border,
                shadowColor: a.color,
                shadowOpacity: 0.12,
                shadowRadius: 10,
                shadowOffset: { width: 0, height: 4 },
                elevation: 3,
              }}
            >
              <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: a.color + '22', alignItems: 'center', justifyContent: 'center', marginBottom: 7 }}>
                <Ionicons name={a.icon} size={19} color={a.color} />
              </View>
              <Text style={{ color: theme.textSecondary, fontSize: 11, fontWeight: '800', textAlign: 'center', lineHeight: 15 }}>
                {a.label}
              </Text>
            </AnimatedPressable>
          ))}
        </View>

        {/* Week chart */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 22, padding: 18, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <Text style={{ color: theme.text, fontSize: 15.5, fontWeight: '900' }}>إنفاق آخر 7 أيام</Text>
            <View style={{ backgroundColor: theme.primarySoft, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 }}>
              <Text style={{ color: theme.primary, fontSize: 11, fontWeight: '800' }}>
                {Math.round(week.reduce((s, d) => s + d.total, 0)).toLocaleString('en-US')} ج.م
              </Text>
            </View>
          </View>
          <BarChart data={week.map((d) => ({ label: d.label, value: d.total, isToday: d.isToday }))} height={130} />
        </LinearGradient>

        {/* Smart insight */}
        {topInsight ? (
          <LinearGradient
            colors={[theme.primary + '26', theme.card]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ borderRadius: 22, padding: 18, borderWidth: 1, borderColor: theme.primary + '44', marginBottom: 16 }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <Ionicons name="sparkles" size={15} color={theme.gold} />
              <Text style={{ color: theme.gold, fontSize: 12.5, fontWeight: '900' }}>تحليل ذكي</Text>
            </View>
            <Text style={{ color: theme.text, fontSize: 15, fontWeight: '900', marginBottom: 4 }}>{topInsight.title}</Text>
            <Text style={{ color: theme.textSecondary, fontSize: 13, lineHeight: 20 }}>{topInsight.message}</Text>
          </LinearGradient>
        ) : null}

        {/* Recent transactions */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>أحدث المعاملات</Text>
          <TouchableOpacity onPress={() => navigation.navigate('TransactionsTab')}>
            <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '800' }}>عرض الكل</Text>
          </TouchableOpacity>
        </View>
        {recent.map((tx) => (
          <AnimatedPressable key={tx.id} onPress={() => navigation.navigate('TransactionDetail', { id: tx.id })}>
            <TransactionItem tx={tx} />
          </AnimatedPressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

