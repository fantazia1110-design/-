import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Switch, Modal, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/AppContext';
import { Card, SectionTitle, PrimaryButton, Toggle } from '../components/ui';
import { CURRENCIES } from '../lib/format';
import { CurrencyCode } from '../lib/types';

export default function SettingsScreen() {
  const { data, theme, updateSettings, resetAll, speak } = useApp();
  const navigation = useNavigation<any>();
  const [name, setName] = useState(data.settings.name);
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);

  const doExport = () => {
    const header = 'التاريخ,النوع,الفئة,الملاحظة,المبلغ\n';
    const rows = data.transactions
      .map((t) => {
        const d = new Date(t.date);
        const date = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        const cat = t.categoryId;
        const note = (t.note || '').replace(/,/g, ' ');
        return `${date},${t.type === 'expense' ? 'مصروف' : 'دخل'},${cat},${note},${t.amount}`;
      })
      .join('\n');
    const csv = '\uFEFF' + header + rows;
    if (Platform.OS === 'web') {
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `masarifi-transactions-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      const { Share } = require('react-native');
      Share.share({ message: csv });
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 10, paddingBottom: 14 }}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}
        >
          <Ionicons name="chevron-back" size={20} color={theme.text} />
        </TouchableOpacity>
        <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>الإعدادات</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 4, paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
        {/* Profile */}
        <LinearGradient colors={[theme.primary + '33', theme.card]} style={{ borderRadius: 24, padding: 20, borderWidth: 1, borderColor: theme.border, alignItems: 'center', marginBottom: 16 }}>
          <View style={{ width: 72, height: 72, borderRadius: 24, backgroundColor: theme.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
            <Text style={{ color: theme.onPrimary, fontSize: 30, fontWeight: '900' }}>
              {data.settings.name.slice(0, 1)}
            </Text>
          </View>
          <Text style={{ color: theme.text, fontSize: 18, fontWeight: '900' }}>{data.settings.name}</Text>
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '700', marginTop: 3 }}>
            {data.transactions.length} معاملة مسجلة
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: theme.inputBg, borderRadius: 14, paddingHorizontal: 14, marginTop: 14, borderWidth: 1, borderColor: theme.border, width: '100%' }}>
            <Ionicons name="person" size={16} color={theme.textMuted} />
            <TextInput
              value={name}
              onChangeText={setName}
              onBlur={() => updateSettings({ name: name.trim() || 'صديقي' })}
              onSubmitEditing={() => updateSettings({ name: name.trim() || 'صديقي' })}
              placeholder="اسمك"
              placeholderTextColor={theme.textMuted}
              style={{ flex: 1, paddingVertical: 12, paddingHorizontal: 10, color: theme.text, fontSize: 14, fontWeight: '700' }}
            />
            <TouchableOpacity onPress={() => updateSettings({ name: name.trim() || 'صديقي' })}>
              <Ionicons name="checkmark-circle" size={22} color={theme.primary} />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* Currency */}
        <SectionTitle title="العملة" />
        <Card style={{ marginBottom: 16, paddingVertical: 8 }}>
          <TouchableOpacity onPress={() => setCurrencyOpen(true)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }}>
            <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.goldSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="cash" size={19} color={theme.gold} />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '800' }}>
                {CURRENCIES[data.settings.currency].name}
              </Text>
              <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700', marginTop: 2 }}>
                {data.settings.currency} • {CURRENCIES[data.settings.currency].symbol}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={17} color={theme.textMuted} />
          </TouchableOpacity>
        </Card>

        {/* Appearance & feedback */}
        <SectionTitle title="المظهر والتغذية الراجعة" />
        <Card style={{ marginBottom: 16, paddingVertical: 6 }}>
          <SettingRow
            icon="moon"
            label="الوضع الداكن"
            value={data.settings.theme === 'dark'}
            onChange={(v) => updateSettings({ theme: v ? 'dark' : 'light' })}
          />
          <SettingRow
            icon="volume-high"
            label="الرد الصوتي"
            value={data.settings.tts}
            onChange={(v) => updateSettings({ tts: v })}
          />
          <SettingRow
            icon="phone-portrait"
            label="الاهتزاز"
            value={data.settings.haptics}
            onChange={(v) => updateSettings({ haptics: v })}
            last
          />
        </Card>

        {/* Data */}
        <SectionTitle title="البيانات" />
        <Card style={{ marginBottom: 16, paddingVertical: 6 }}>
          <TouchableOpacity onPress={doExport} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12 }}>
            <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.blue + '22', alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="download" size={18} color={theme.blue} />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '800' }}>تصدير البيانات (CSV)</Text>
              <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700', marginTop: 2 }}>
                كل المعاملات في ملف جاهز للExcel
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={17} color={theme.textMuted} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setResetConfirm(true)}
            style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderTopWidth: 1, borderTopColor: theme.border }}
          >
            <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.dangerSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="refresh" size={18} color={theme.danger} />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={{ color: theme.danger, fontSize: 14.5, fontWeight: '800' }}>إعادة تعيين البيانات</Text>
              <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700', marginTop: 2 }}>
                استعادة البيانات التجريبية
              </Text>
            </View>
          </TouchableOpacity>
        </Card>

        {/* About */}
        <LinearGradient colors={[theme.primary, theme.primaryDeep]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ borderRadius: 24, padding: 22, alignItems: 'center' }}>
          <View style={{ width: 56, height: 56, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}>
            <Ionicons name="wallet" size={28} color="#fff" />
          </View>
          <Text style={{ color: '#fff', fontSize: 19, fontWeight: '900' }}>مصاريفي</Text>
          <Text style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12.5, fontWeight: '700', marginTop: 4, textAlign: 'center', lineHeight: 19 }}>
            تتبع مصاريفك اليومية والشهرية، حلل إنفاقك بالذكاء الاصطناعي، وادخر لأحلامك — كل ذلك بصوتك وكتابتك.
          </Text>
          <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: '700', marginTop: 12 }}>الإصدار 1.0.0</Text>
        </LinearGradient>
      </ScrollView>

      {/* Currency picker modal */}
      <Modal visible={currencyOpen} transparent animationType="fade" onRequestClose={() => setCurrencyOpen(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 20, borderWidth: 1, borderColor: theme.border }}>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>اختر العملة</Text>
            {Object.values(CURRENCIES).map((c) => {
              const active = data.settings.currency === c.code;
              return (
                <TouchableOpacity
                  key={c.code}
                  onPress={() => {
                    updateSettings({ currency: c.code as CurrencyCode });
                    setCurrencyOpen(false);
                  }}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 13,
                    borderRadius: 14,
                    backgroundColor: active ? theme.primarySoft : 'transparent',
                    borderWidth: 1,
                    borderColor: active ? theme.primary : theme.border,
                    marginBottom: 8,
                  }}
                >
                  <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '800', flex: 1 }}>{c.name}</Text>
                  <Text style={{ color: theme.textSecondary, fontSize: 13, fontWeight: '800' }}>{c.symbol}</Text>
                  {active ? <Ionicons name="checkmark-circle" size={18} color={theme.primary} style={{ marginLeft: 8 }} /> : null}
                </TouchableOpacity>
              );
            })}
            <TouchableOpacity onPress={() => setCurrencyOpen(false)} style={{ alignItems: 'center', padding: 12 }}>
              <Text style={{ color: theme.textSecondary, fontSize: 14, fontWeight: '800' }}>إلغاء</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Reset confirm */}
      <Modal visible={resetConfirm} transparent animationType="fade" onRequestClose={() => setResetConfirm(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
            <View style={{ width: 52, height: 52, borderRadius: 17, backgroundColor: theme.dangerSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
              <Ionicons name="warning" size={24} color={theme.danger} />
            </View>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 6 }}>إعادة تعيين البيانات؟</Text>
            <Text style={{ color: theme.textSecondary, fontSize: 13.5, lineHeight: 20, marginBottom: 18 }}>
              سيتم حذف كل معاملاتك واستعادة البيانات التجريبية. لا يمكن التراجع.
            </Text>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <PrimaryButton
                  label="نعم، إعادة"
                  icon="refresh"
                  small
                  color={theme.danger}
                  onPress={() => {
                    resetAll();
                    setResetConfirm(false);
                  }}
                />
              </View>
              <View style={{ flex: 1 }}>
                <PrimaryButton label="تراجع" small outline onPress={() => setResetConfirm(false)} />
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function SettingRow({ icon, label, value, onChange, last }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  last?: boolean;
}) {
  const { theme } = useApp();
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        borderTopWidth: last ? 0 : 1,
        borderTopColor: theme.border,
      }}
    >
      <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name={icon} size={18} color={theme.primary} />
      </View>
      <Text style={{ color: theme.text, fontSize: 14.5, fontWeight: '800', flex: 1, marginLeft: 12 }}>{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ false: theme.chartTrack, true: theme.primary }} thumbColor="#fff" />
    </View>
  );
}
