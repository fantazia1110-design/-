import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/AppContext';
import { Card, SectionTitle, EmptyState } from '../components/ui';
import { DonutChart, BarChart, TrendChart } from '../components/charts';
import { getMonthTransactions, getLastMonthTransactions, getTotals, getCategoryBreakdown, getDailySeries, getCumulativeSeries, generateInsights, getTopTransactions } from '../lib/analytics';
import { formatMoney, formatMonthYear, formatDateLabel, formatTime } from '../lib/format';
import { getCategory } from '../lib/categories';

export default function AnalyticsScreen() {
  const { data, theme } = useApp();
  const navigation = useNavigation<any>();
  const [monthOffset, setMonthOffset] = useState(0);

  const ref = useMemo(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth() - monthOffset, 1);
  }, [monthOffset]);

  const monthTx = useMemo(() => getMonthTransactions(data.transactions, ref), [data.transactions, ref]);
  const lastMonthTx = useMemo(() => getLastMonthTransactions(data.transactions, ref), [data.transactions, ref]);
  const totals = useMemo(() => getTotals(monthTx), [monthTx]);
  const lastTotals = useMemo(() => getTotals(lastMonthTx), [lastMonthTx]);
  const breakdown = useMemo(() => getCategoryBreakdown(monthTx, 'expense').slice(0, 6), [monthTx]);
  const daily = useMemo(() => getDailySeries(monthTx, ref), [monthTx, ref]);
  const cumulative = useMemo(() => getCumulativeSeries(monthTx, ref), [monthTx, ref]);
  const insights = useMemo(
    () => generateInsights(data.transactions, data.budgets, data.goals, data.settings.currency, ref),
    [data.transactions, data.budgets, data.goals, ref]
  );
  const topTxs = useMemo(() => getTopTransactions(monthTx.filter((t) => t.type === 'expense'), 3), [monthTx]);

  const otherTotal = breakdown.length >= 6
    ? getCategoryBreakdown(monthTx, 'expense').slice(6).reduce((s, c) => s + c.total, 0)
    : 0;

  const donutData = [
    ...breakdown.map((b) => ({ label: getCategory(b.categoryId).name, value: b.total, color: getCategory(b.categoryId).color })),
    ...(otherTotal > 0 ? [{ label: 'أخرى', value: otherTotal, color: '#5D6B7F' }] : []),
  ];

  const momChange = lastTotals.expense > 0 ? ((totals.expense - lastTotals.expense) / lastTotals.expense) * 100 : 0;
  const daysInMonth = new Date(ref.getFullYear(), ref.getMonth() + 1, 0).getDate();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 130 }} showsVerticalScrollIndicator={false}>
        <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900' }}>التقارير والتحليل</Text>
        <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '700', marginTop: 2, marginBottom: 16 }}>
          تحليل شامل لكل معاملاتك
        </Text>

        {/* Month pager */}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: theme.card, borderRadius: 16, padding: 8, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <TouchableOpacity onPress={() => setMonthOffset((o) => o + 1)} style={{ padding: 10 }}>
            <Ionicons name="chevron-forward" size={18} color={theme.text} />
          </TouchableOpacity>
          <Text style={{ color: theme.text, fontSize: 15, fontWeight: '900' }}>{formatMonthYear(ref)}</Text>
          <TouchableOpacity onPress={() => setMonthOffset((o) => Math.max(0, o - 1))} style={{ padding: 10, opacity: monthOffset === 0 ? 0.3 : 1 }} disabled={monthOffset === 0}>
            <Ionicons name="chevron-back" size={18} color={theme.text} />
          </TouchableOpacity>
        </View>

        {/* Stat cards */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 16 }}>
          {[
            { label: 'إجمالي المصروفات', value: formatMoney(totals.expense, data.settings.currency), icon: 'arrow-up-circle' as const, color: theme.danger, delta: momChange },
            { label: 'إجمالي الدخول', value: formatMoney(totals.income, data.settings.currency), icon: 'arrow-down-circle' as const, color: theme.success },
            { label: 'متوسط الإنفاق اليومي', value: formatMoney(totals.expense / Math.max(ref.getDate(), 1), data.settings.currency), icon: 'speedometer' as const, color: theme.blue },
            { label: 'عدد المعاملات', value: `${monthTx.length}`, icon: 'swap-horizontal' as const, color: theme.primary },
          ].map((s) => (
            <View key={s.label} style={{ width: '47.5%', flexGrow: 1, backgroundColor: theme.card, borderRadius: 18, padding: 14, borderWidth: 1, borderColor: theme.border }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Ionicons name={s.icon} size={13} color={s.color} />
                <Text style={{ color: theme.textMuted, fontSize: 11, fontWeight: '800' }}>{s.label}</Text>
              </View>
              <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>{s.value}</Text>
              {s.delta !== undefined && s.delta !== 0 ? (
                <Text style={{ color: s.delta > 0 ? theme.danger : theme.primary, fontSize: 11, fontWeight: '800', marginTop: 4 }}>
                  {s.delta > 0 ? '↑' : '↓'} {Math.abs(s.delta).toFixed(0)}% عن الشهر الماضي
                </Text>
              ) : null}
            </View>
          ))}
        </View>

        {/* Donut */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 18, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <SectionTitle title="توزيع المصروفات حسب الفئة" />
          {donutData.length > 0 ? (
            <View style={{ alignItems: 'center' }}>
              <DonutChart data={donutData} size={200} strokeWidth={24} centerTitle="إجمالي" centerValue={`${Math.round(totals.expense).toLocaleString('en-US')}`} />
              <View style={{ width: '100%', marginTop: 16 }}>
                {breakdown.map((b) => {
                  const cat = getCategory(b.categoryId);
                  return (
                    <View key={b.categoryId} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: cat.color }} />
                      <Text style={{ color: theme.text, fontSize: 13, fontWeight: '800', marginLeft: 8, flex: 1 }}>{cat.name}</Text>
                      <Text style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '700' }}>
                        {Math.round(b.total).toLocaleString('en-US')} ج.م • {(b.pct * 100).toFixed(0)}%
                      </Text>
                    </View>
                  );
                })}
              </View>
            </View>
          ) : (
            <EmptyState icon="pie-chart-outline" title="لا توجد مصروفات" message="لم تسجل أي مصروفات في هذا الشهر بعد" />
          )}
        </LinearGradient>

        {/* Daily bars */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 18, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <SectionTitle title="الإنفاق اليومي في الشهر" />
          <BarChart data={daily.map((d) => ({ label: d.label, value: d.total, isToday: d.isToday }))} height={150} />
        </LinearGradient>

        {/* Trend */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 18, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <SectionTitle title="الإنفاق التراكمي مقابل الشهر الماضي" />
          <TrendChart series={cumulative} height={160} labelEvery={Math.ceil(daysInMonth / 6)} />
          <View style={{ flexDirection: 'row', gap: 16, marginTop: 10, justifyContent: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: theme.primary }} />
              <Text style={{ color: theme.textSecondary, fontSize: 11.5, fontWeight: '700' }}>هذا الشهر</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: theme.textMuted }} />
              <Text style={{ color: theme.textSecondary, fontSize: 11.5, fontWeight: '700' }}>الشهر الماضي</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Insights */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 18, borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <Ionicons name="sparkles" size={16} color={theme.gold} />
            <Text style={{ color: theme.text, fontSize: 16, fontWeight: '900' }}>رؤى ذكية</Text>
          </View>
          {insights.map((ins) => (
            <View key={ins.id} style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 14 }}>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: ins.color + '22', alignItems: 'center', justifyContent: 'center', marginLeft: 12 }}>
                <Ionicons name={ins.icon as any} size={17} color={ins.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.text, fontSize: 13.5, fontWeight: '900', marginBottom: 2 }}>{ins.title}</Text>
                <Text style={{ color: theme.textSecondary, fontSize: 12.5, lineHeight: 19 }}>{ins.message}</Text>
              </View>
            </View>
          ))}
        </LinearGradient>

        {/* Top transactions */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 18, borderWidth: 1, borderColor: theme.border }}>
          <SectionTitle title="أكبر المعاملات" />
          {topTxs.map((tx, i) => {
            const cat = getCategory(tx.categoryId);
            return (
              <View key={tx.id} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
                <Text style={{ color: theme.textMuted, fontSize: 13, fontWeight: '900', width: 20 }}>{i + 1}</Text>
                <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: cat.color + '22', alignItems: 'center', justifyContent: 'center', marginLeft: 10 }}>
                  <Ionicons name={cat.icon} size={16} color={cat.color} />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={{ color: theme.text, fontSize: 13, fontWeight: '800' }} numberOfLines={1}>
                    {tx.note || cat.name}
                  </Text>
                  <Text style={{ color: theme.textMuted, fontSize: 11, fontWeight: '700', marginTop: 2 }}>
                    {formatDateLabel(tx.date)} • {formatTime(tx.date)}
                  </Text>
                </View>
                <Text style={{ color: theme.text, fontSize: 14, fontWeight: '900' }}>
                  {Math.round(tx.amount).toLocaleString('en-US')} ج.م
                </Text>
              </View>
            );
          })}
        </LinearGradient>
      </ScrollView>
    </SafeAreaView>
  );
}
