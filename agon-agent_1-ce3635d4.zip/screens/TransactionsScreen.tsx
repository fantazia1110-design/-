import React, { useMemo, useState } from 'react';
import { View, Text, SectionList, TextInput, TouchableOpacity, ScrollView, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../lib/AppContext';
import { Chip, EmptyState } from '../components/ui';
import TransactionItem from '../components/TransactionItem';
import { Transaction } from '../lib/types';
import { formatDateLabel, formatMoney } from '../lib/format';
import { getCategory, EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../lib/categories';
import { getTotals } from '../lib/analytics';

interface Section {
  title: string;
  data: Transaction[];
}

export default function TransactionsScreen() {
  const { data, theme } = useApp();
  const navigation = useNavigation<any>();
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'expense' | 'income'>('all');
  const [catFilter, setCatFilter] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const filtered = useMemo(() => {
    let out = data.transactions;
    if (typeFilter !== 'all') out = out.filter((t) => t.type === typeFilter);
    if (catFilter) out = out.filter((t) => t.categoryId === catFilter);
    if (query.trim()) {
      const q = query.trim();
      out = out.filter(
        (t) => t.note.includes(q) || getCategory(t.categoryId).name.includes(q) || Math.round(t.amount).toString().includes(q)
      );
    }
    return out;
  }, [data.transactions, typeFilter, catFilter, query]);

  const sections = useMemo<Section[]>(() => {
    const groups = new Map<string, Transaction[]>();
    for (const t of filtered) {
      const label = formatDateLabel(t.date);
      if (!groups.has(label)) groups.set(label, []);
      groups.get(label)!.push(t);
    }
    return Array.from(groups.entries()).map(([title, txs]) => ({ title, data: txs }));
  }, [filtered]);

  const totals = useMemo(() => getTotals(filtered), [filtered]);
  const allCats = [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <View style={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: 6 }}>
        <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900' }}>المعاملات</Text>
        <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '700', marginTop: 2 }}>
          {filtered.length} معاملة • دخل {Math.round(totals.income).toLocaleString('en-US')} • مصروف {Math.round(totals.expense).toLocaleString('en-US')}
        </Text>
      </View>

      {/* Search */}
      <View style={{ paddingHorizontal: 20, marginTop: 12 }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: theme.card,
            borderRadius: 16,
            paddingHorizontal: 14,
            borderWidth: 1,
            borderColor: theme.border,
            gap: 10,
          }}
        >
          <Ionicons name="search" size={18} color={theme.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="ابحث بالملاحظة أو الفئة أو المبلغ..."
            placeholderTextColor={theme.textMuted}
            style={{ flex: 1, paddingVertical: 13, color: theme.text, fontSize: 14, fontWeight: '600' }}
          />
          {query ? (
            <TouchableOpacity onPress={() => setQuery('')}>
              <Ionicons name="close-circle" size={18} color={theme.textMuted} />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* Type filter */}
      <View style={{ flexDirection: 'row', paddingHorizontal: 20, marginTop: 12 }}>
        {(
          [
            { id: 'all', label: 'الكل' },
            { id: 'expense', label: 'مصروفات' },
            { id: 'income', label: 'دخول' },
          ] as const
        ).map((f) => (
          <Chip key={f.id} label={f.label} active={typeFilter === f.id} onPress={() => setTypeFilter(f.id)} color={f.id === 'income' ? theme.primary : f.id === 'expense' ? theme.danger : theme.primary} />
        ))}
      </View>

      {/* Category filter */}
      <View style={{ marginTop: 10 }}>
        <SectionList
          horizontal
          showsHorizontalScrollIndicator={false}
          sections={[{ title: 'cats', data: allCats }]}
          keyExtractor={(c) => c.id}
          renderSectionHeader={() => null}
          contentContainerStyle={{ paddingHorizontal: 20 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setCatFilter(catFilter === item.id ? null : item.id)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                paddingHorizontal: 12,
                paddingVertical: 7,
                borderRadius: 999,
                backgroundColor: catFilter === item.id ? item.color : theme.cardAlt,
                borderWidth: 1,
                borderColor: catFilter === item.id ? item.color : theme.border,
                marginLeft: 8,
              }}
            >
              <Ionicons name={item.icon} size={13} color={catFilter === item.id ? theme.onPrimary : item.color} />
              <Text style={{ color: catFilter === item.id ? theme.onPrimary : theme.textSecondary, fontSize: 12, fontWeight: '700' }}>
                {item.name}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* List */}
      <SectionList
        sections={sections}
        keyExtractor={(t) => t.id}
        stickySectionHeadersEnabled
        contentContainerStyle={{ padding: 20, paddingTop: 14, paddingBottom: 130 }}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={() => {}}
            tintColor={theme.primary}
          />
        }
        renderSectionHeader={({ section }) => (
          <View style={{ backgroundColor: theme.bg, paddingVertical: 8 }}>
            <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800' }}>{section.title}</Text>
          </View>
        )}
        renderItem={({ item }) => (
          <TouchableOpacity activeOpacity={0.75} onPress={() => navigation.navigate('TransactionDetail', { id: item.id })}>
            <TransactionItem tx={item} />
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="receipt-outline"
            title="لا توجد معاملات"
            message="جرّب تعديل الفلاتر أو أضف معاملة جديدة من زر الإضافة"
            actionLabel="أضف معاملة"
            onAction={() => navigation.navigate('AddTransaction', {})}
          />
        }
      />
    </SafeAreaView>
  );
}

