import React, { useMemo, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Modal, Switch, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../lib/AppContext';
import { Card, SectionTitle, PrimaryButton, Chip, Toggle } from '../components/ui';
import { ProgressRing } from '../components/charts';
import { getMonthTransactions, getTotals, getCategoryBreakdown } from '../lib/analytics';
import { formatMoney } from '../lib/format';
import { getCategory, EXPENSE_CATEGORIES } from '../lib/categories';
import { RecurringFrequency } from '../lib/types';

export default function BudgetsScreen() {
  const { data, theme, addBudget, updateBudget, deleteBudget, addGoal, updateGoal, deleteGoal, addRecurring, deleteRecurring, updateRecurring, updateSettings, haptic } = useApp();
  const now = new Date();
  const monthTx = useMemo(() => getMonthTransactions(data.transactions, now), [data.transactions]);
  const totals = useMemo(() => getTotals(monthTx), [monthTx]);
  const breakdown = useMemo(() => getCategoryBreakdown(monthTx, 'expense'), [monthTx]);

  const overall = data.budgets.find((b) => b.categoryId === 'overall');
  const catBudgets = data.budgets.filter((b) => b.categoryId !== 'overall');
  const spentPct = totals.expense / Math.max(overall?.limit || data.settings.budgetOverall || 1, 1);

  // Modals state
  const [editOverall, setEditOverall] = useState(false);
  const [overallVal, setOverallVal] = useState('');
  const [addCatBudget, setAddCatBudget] = useState(false);
  const [catBudgetVal, setCatBudgetVal] = useState('');
  const [catBudgetCat, setCatBudgetCat] = useState('food');
  const [addGoalOpen, setAddGoalOpen] = useState(false);
  const [goalName, setGoalName] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [goalColor, setGoalColor] = useState('#5B9DFF');
  const [fundGoal, setFundGoal] = useState<string | null>(null);
  const [fundVal, setFundVal] = useState('');
  const [addRecurringOpen, setAddRecurringOpen] = useState(false);
  const [recType, setRecType] = useState<'expense' | 'income'>('expense');
  const [recAmount, setRecAmount] = useState('');
  const [recCat, setRecCat] = useState('food');
  const [recNote, setRecNote] = useState('');
  const [recFreq, setRecFreq] = useState<RecurringFrequency>('monthly');

  const goalColors = ['#5B9DFF', '#12D69F', '#F6C445', '#FF8A5C', '#A78BFA', '#F472B6'];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 130 }} showsVerticalScrollIndicator={false}>
        <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900' }}>الميزانية والأهداف</Text>
        <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '700', marginTop: 2, marginBottom: 18 }}>
          تحكم في إنفاقك وادخر لأحلامك
        </Text>

        {/* Overall budget */}
        <LinearGradient colors={[theme.card, theme.cardAlt]} style={{ borderRadius: 24, padding: 20, borderWidth: 1, borderColor: theme.border, alignItems: 'center', marginBottom: 16 }}>
          <Text style={{ color: theme.textMuted, fontSize: 12.5, fontWeight: '800', marginBottom: 14 }}>الميزانية الشهرية الإجمالية</Text>
          <ProgressRing size={150} strokeWidth={14} progress={Math.min(spentPct, 1)} color={spentPct > 0.9 ? theme.danger : theme.primary}>
            <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900' }}>{Math.round(spentPct * 100)}%</Text>
            <Text style={{ color: theme.textMuted, fontSize: 11, fontWeight: '700' }}>مستهلك</Text>
          </ProgressRing>
          <Text style={{ color: theme.text, fontSize: 14, fontWeight: '800', marginTop: 14 }}>
            {formatMoney(totals.expense, data.settings.currency)} من {formatMoney(overall?.limit || data.settings.budgetOverall, data.settings.currency)}
          </Text>
          <Text style={{ color: spentPct > 1 ? theme.danger : theme.primary, fontSize: 12.5, fontWeight: '800', marginTop: 4 }}>
            {spentPct > 1
              ? `تجاوزت الميزانية بـ ${formatMoney(totals.expense - (overall?.limit || 0), data.settings.currency)}`
              : `متبقي ${formatMoney((overall?.limit || data.settings.budgetOverall) - totals.expense, data.settings.currency)}`}
          </Text>
          <TouchableOpacity
            onPress={() => {
              setOverallVal(String(overall?.limit || data.settings.budgetOverall));
              setEditOverall(true);
            }}
            style={{ marginTop: 14, backgroundColor: theme.primarySoft, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 9 }}
          >
            <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '800' }}>تعديل الميزانية</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Category budgets */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>ميزانيات الفئات</Text>
          <TouchableOpacity
            onPress={() => {
              setCatBudgetVal('');
              setAddCatBudget(true);
            }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
          >
            <Ionicons name="add-circle" size={16} color={theme.primary} />
            <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '800' }}>إضافة</Text>
          </TouchableOpacity>
        </View>
        {catBudgets.map((b) => {
          const cat = getCategory(b.categoryId);
          const spent = breakdown.find((x) => x.categoryId === b.categoryId)?.total || 0;
          const pct = Math.min(spent / Math.max(b.limit, 1), 1);
          return (
            <View key={b.id} style={{ backgroundColor: theme.card, borderRadius: 18, padding: 14, borderWidth: 1, borderColor: theme.border, marginBottom: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: cat.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={cat.icon} size={17} color={cat.color} />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={{ color: theme.text, fontSize: 14, fontWeight: '800' }}>{cat.name}</Text>
                  <Text style={{ color: theme.textMuted, fontSize: 11.5, fontWeight: '700', marginTop: 2 }}>
                    {formatMoney(spent, data.settings.currency)} من {formatMoney(b.limit, data.settings.currency)}
                  </Text>
                </View>
                <Text style={{ color: pct > 0.9 ? theme.danger : theme.primary, fontSize: 13, fontWeight: '900' }}>
                  {Math.round(pct * 100)}%
                </Text>
                <TouchableOpacity onPress={() => deleteBudget(b.id)} style={{ marginLeft: 10 }}>
                  <Ionicons name="trash-outline" size={17} color={theme.textMuted} />
                </TouchableOpacity>
              </View>
              <View style={{ height: 7, borderRadius: 4, backgroundColor: theme.chartTrack, overflow: 'hidden' }}>
                <View style={{ width: `${pct * 100}%`, height: '100%', backgroundColor: pct > 0.9 ? theme.danger : cat.color, borderRadius: 4 }} />
              </View>
            </View>
          );
        })}
        {catBudgets.length === 0 ? (
          <Text style={{ color: theme.textMuted, fontSize: 13, fontWeight: '600', textAlign: 'center', marginBottom: 16 }}>
            لا توجد ميزانيات فئات — أضف واحدة لتتحكم في إنفاقك
          </Text>
        ) : null}

        {/* Goals */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, marginBottom: 12 }}>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>أهداف التوفير</Text>
          <TouchableOpacity
            onPress={() => {
              setGoalName('');
              setGoalTarget('');
              setAddGoalOpen(true);
            }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
          >
            <Ionicons name="add-circle" size={16} color={theme.primary} />
            <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '800' }}>هدف جديد</Text>
          </TouchableOpacity>
        </View>
        {data.goals.map((g) => {
          const pct = Math.min(g.saved / Math.max(g.target, 1), 1);
          return (
            <View key={g.id} style={{ backgroundColor: theme.card, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: theme.border, marginBottom: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
                <View style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: g.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={g.icon as any} size={20} color={g.color} />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={{ color: theme.text, fontSize: 15, fontWeight: '900' }}>{g.name}</Text>
                  <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700', marginTop: 2 }}>
                    {formatMoney(g.saved, data.settings.currency)} من {formatMoney(g.target, data.settings.currency)}
                  </Text>
                </View>
                <Text style={{ color: g.color, fontSize: 15, fontWeight: '900' }}>{Math.round(pct * 100)}%</Text>
              </View>
              <View style={{ height: 9, borderRadius: 5, backgroundColor: theme.chartTrack, overflow: 'hidden', marginBottom: 12 }}>
                <View style={{ width: `${pct * 100}%`, height: '100%', backgroundColor: g.color, borderRadius: 5 }} />
              </View>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TouchableOpacity
                  onPress={() => {
                    setFundVal('');
                    setFundGoal(g.id);
                  }}
                  style={{ flex: 1, backgroundColor: theme.primarySoft, borderRadius: 12, paddingVertical: 9, alignItems: 'center' }}
                >
                  <Text style={{ color: theme.primary, fontSize: 12.5, fontWeight: '800' }}>أضف مبلغ</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => deleteGoal(g.id)}
                  style={{ width: 42, backgroundColor: theme.dangerSoft, borderRadius: 12, alignItems: 'center', justifyContent: 'center' }}
                >
                  <Ionicons name="trash-outline" size={16} color={theme.danger} />
                </TouchableOpacity>
              </View>
            </View>
          );
        })}
        {data.goals.length === 0 ? (
          <Text style={{ color: theme.textMuted, fontSize: 13, fontWeight: '600', textAlign: 'center', marginBottom: 16 }}>
            لا توجد أهداف بعد — أنشئ هدفك الأول!
          </Text>
        ) : null}

        {/* Recurring */}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, marginBottom: 12 }}>
          <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>المعاملات المتكررة</Text>
          <TouchableOpacity
            onPress={() => {
              setRecAmount('');
              setRecNote('');
              setAddRecurringOpen(true);
            }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
          >
            <Ionicons name="add-circle" size={16} color={theme.primary} />
            <Text style={{ color: theme.primary, fontSize: 13, fontWeight: '800' }}>إضافة</Text>
          </TouchableOpacity>
        </View>
        {data.recurring.map((r) => {
          const cat = getCategory(r.categoryId);
          const freqLabel = r.frequency === 'daily' ? 'يومي' : r.frequency === 'weekly' ? 'أسبوعي' : 'شهري';
          return (
            <View key={r.id} style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: theme.card, borderRadius: 16, padding: 13, borderWidth: 1, borderColor: theme.border, marginBottom: 10 }}>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: cat.color + '22', alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={cat.icon} size={17} color={cat.color} />
              </View>
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={{ color: theme.text, fontSize: 13.5, fontWeight: '800' }}>{r.note || cat.name}</Text>
                <Text style={{ color: theme.textMuted, fontSize: 11.5, fontWeight: '700', marginTop: 2 }}>
                  {freqLabel} • {Math.round(r.amount).toLocaleString('en-US')} ج.م
                </Text>
              </View>
              <Switch value={r.active} onValueChange={(v) => updateRecurring(r.id, { active: v })} trackColor={{ false: theme.chartTrack, true: theme.primary }} thumbColor="#fff" />
              <TouchableOpacity onPress={() => deleteRecurring(r.id)} style={{ marginLeft: 10 }}>
                <Ionicons name="trash-outline" size={16} color={theme.textMuted} />
              </TouchableOpacity>
            </View>
          );
        })}
      </ScrollView>

      {/* ---- Modals ---- */}
      {/* Edit overall budget */}
      <Modal visible={editOverall} transparent animationType="fade" onRequestClose={() => setEditOverall(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>الميزانية الشهرية الإجمالية</Text>
            <TextInput
              value={overallVal}
              onChangeText={(t) => setOverallVal(t.replace(/[^0-9.]/g, ''))}
              keyboardType="decimal-pad"
              placeholder="18000"
              placeholderTextColor={theme.textMuted}
              style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 14, color: theme.text, fontSize: 17, fontWeight: '800', borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}
            />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <PrimaryButton
                  label="حفظ"
                  icon="checkmark"
                  small
                  onPress={() => {
                    const v = parseFloat(overallVal);
                    if (v > 0) {
                      if (overall) updateBudget(overall.id, { limit: v });
                      else addBudget({ categoryId: 'overall', limit: v });
                      updateSettings({ budgetOverall: v });
                      haptic('success');
                    }
                    setEditOverall(false);
                  }}
                />
              </View>
              <View style={{ flex: 1 }}>
                <PrimaryButton label="إلغاء" small outline onPress={() => setEditOverall(false)} />
              </View>
            </View>
          </View>
        </View>
      </Modal>

      {/* Add category budget */}
      <Modal visible={addCatBudget} transparent animationType="fade" onRequestClose={() => setAddCatBudget(false)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>ميزانية فئة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
              {EXPENSE_CATEGORIES.slice(0, 10).map((c) => (
                <Chip key={c.id} label={c.name} active={catBudgetCat === c.id} onPress={() => setCatBudgetCat(c.id)} color={c.color} />
              ))}
            </ScrollView>
            <TextInput
              value={catBudgetVal}
              onChangeText={(t) => setCatBudgetVal(t.replace(/[^0-9.]/g, ''))}
              keyboardType="decimal-pad"
              placeholder="الحد الشهري"
              placeholderTextColor={theme.textMuted}
              style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 14, color: theme.text, fontSize: 16, fontWeight: '800', borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}
            />
            <PrimaryButton
              label="حفظ"
              icon="checkmark"
              small
              onPress={() => {
                const v = parseFloat(catBudgetVal);
                if (v > 0) {
                  const existing = data.budgets.find((b) => b.categoryId === catBudgetCat);
                  if (existing) updateBudget(existing.id, { limit: v });
                  else addBudget({ categoryId: catBudgetCat, limit: v });
                  haptic('success');
                }
                setAddCatBudget(false);
              }}
            />
          </View>
        </View>
      </Modal>

      {/* Add goal */}
      <Modal visible={addGoalOpen} transparent animationType="fade" onRequestClose={() => setAddGoalOpen(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
            <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
              <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>هدف توفير جديد</Text>
              <TextInput
                value={goalName}
                onChangeText={setGoalName}
                placeholder="اسم الهدف (مثلاً: سفر إلى إيطاليا)"
                placeholderTextColor={theme.textMuted}
                style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 14, color: theme.text, fontSize: 15, fontWeight: '700', borderWidth: 1, borderColor: theme.border, marginBottom: 12 }}
              />
              <TextInput
                value={goalTarget}
                onChangeText={(t) => setGoalTarget(t.replace(/[^0-9.]/g, ''))}
                keyboardType="decimal-pad"
                placeholder="المبلغ المستهدف"
                placeholderTextColor={theme.textMuted}
                style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 14, color: theme.text, fontSize: 15, fontWeight: '700', borderWidth: 1, borderColor: theme.border, marginBottom: 12 }}
              />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
                {goalColors.map((c) => (
                  <TouchableOpacity
                    key={c}
                    onPress={() => setGoalColor(c)}
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 17,
                      backgroundColor: c,
                      marginLeft: 8,
                      borderWidth: 3,
                      borderColor: goalColor === c ? theme.text : 'transparent',
                    }}
                  />
                ))}
              </ScrollView>
              <PrimaryButton
                label="إنشاء الهدف"
                icon="flag"
                small
                onPress={() => {
                  const v = parseFloat(goalTarget);
                  if (goalName.trim() && v > 0) {
                    addGoal({ name: goalName.trim(), target: v, saved: 0, color: goalColor, icon: 'flag' });
                    haptic('success');
                  }
                  setAddGoalOpen(false);
                }}
              />
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Fund goal */}
      <Modal visible={!!fundGoal} transparent animationType="fade" onRequestClose={() => setFundGoal(null)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
          <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>أضف مبلغ للهدف</Text>
            <TextInput
              value={fundVal}
              onChangeText={(t) => setFundVal(t.replace(/[^0-9.]/g, ''))}
              keyboardType="decimal-pad"
              placeholder="المبلغ"
              placeholderTextColor={theme.textMuted}
              style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 14, color: theme.text, fontSize: 16, fontWeight: '800', borderWidth: 1, borderColor: theme.border, marginBottom: 16 }}
            />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <PrimaryButton
                  label="إضافة"
                  icon="add"
                  small
                  onPress={() => {
                    const v = parseFloat(fundVal);
                    const g = data.goals.find((x) => x.id === fundGoal);
                    if (v > 0 && g) {
                      updateGoal(g.id, { saved: g.saved + v });
                      haptic('success');
                    }
                    setFundGoal(null);
                  }}
                />
              </View>
              <View style={{ flex: 1 }}>
                <PrimaryButton label="سحب مبلغ" small outline onPress={() => {
                  const v = parseFloat(fundVal);
                  const g = data.goals.find((x) => x.id === fundGoal);
                  if (v > 0 && g) updateGoal(g.id, { saved: Math.max(0, g.saved - v) });
                  setFundGoal(null);
                }} />
              </View>
            </View>
          </View>
        </View>
      </Modal>

      {/* Add recurring */}
      <Modal visible={addRecurringOpen} transparent animationType="fade" onRequestClose={() => setAddRecurringOpen(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
          <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', justifyContent: 'center', padding: 24 }}>
            <View style={{ backgroundColor: theme.card, borderRadius: 24, padding: 22, borderWidth: 1, borderColor: theme.border }}>
              <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginBottom: 14 }}>معاملة متكررة</Text>
              <View style={{ flexDirection: 'row', backgroundColor: theme.cardAlt, borderRadius: 14, padding: 4, marginBottom: 12 }}>
                {(['expense', 'income'] as const).map((t) => (
                  <TouchableOpacity
                    key={t}
                    onPress={() => setRecType(t)}
                    style={{ flex: 1, paddingVertical: 9, borderRadius: 11, backgroundColor: recType === t ? (t === 'expense' ? theme.danger : theme.primary) : 'transparent', alignItems: 'center' }}
                  >
                    <Text style={{ color: recType === t ? '#fff' : theme.textSecondary, fontSize: 13, fontWeight: '800' }}>
                      {t === 'expense' ? 'مصروف' : 'دخل'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TextInput
                value={recAmount}
                onChangeText={(t) => setRecAmount(t.replace(/[^0-9.]/g, ''))}
                keyboardType="decimal-pad"
                placeholder="المبلغ"
                placeholderTextColor={theme.textMuted}
                style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 13, color: theme.text, fontSize: 15, fontWeight: '800', borderWidth: 1, borderColor: theme.border, marginBottom: 12 }}
              />
              <TextInput
                value={recNote}
                onChangeText={setRecNote}
                placeholder="ملاحظة (مثلاً: إيجار الشقة)"
                placeholderTextColor={theme.textMuted}
                style={{ backgroundColor: theme.inputBg, borderRadius: 14, padding: 13, color: theme.text, fontSize: 14, fontWeight: '700', borderWidth: 1, borderColor: theme.border, marginBottom: 12 }}
              />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                {EXPENSE_CATEGORIES.slice(0, 8).map((c) => (
                  <Chip key={c.id} label={c.name} active={recCat === c.id} onPress={() => setRecCat(c.id)} color={c.color} />
                ))}
              </ScrollView>
              <View style={{ flexDirection: 'row', marginBottom: 16 }}>
                {(['daily', 'weekly', 'monthly'] as const).map((f) => (
                  <Chip key={f} label={f === 'daily' ? 'يومي' : f === 'weekly' ? 'أسبوعي' : 'شهري'} active={recFreq === f} onPress={() => setRecFreq(f)} />
                ))}
              </View>
              <PrimaryButton
                label="حفظ"
                icon="checkmark"
                small
                onPress={() => {
                  const v = parseFloat(recAmount);
                  if (v > 0) {
                    const next = new Date();
                    if (recFreq === 'daily') next.setDate(next.getDate() + 1);
                    else if (recFreq === 'weekly') next.setDate(next.getDate() + 7);
                    else next.setMonth(next.getMonth() + 1);
                    addRecurring({ type: recType, amount: v, categoryId: recCat, note: recNote, frequency: recFreq, nextDate: next.toISOString(), active: true });
                    haptic('success');
                  }
                  setAddRecurringOpen(false);
                }}
              />
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}
