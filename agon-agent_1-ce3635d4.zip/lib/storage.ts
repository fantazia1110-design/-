import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppData } from './types';

const KEY = '@masarifi_data_v1';

export async function loadData(): Promise<AppData | null> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AppData;
  } catch {
    return null;
  }
}

export async function saveData(data: AppData): Promise<void> {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(data));
  } catch {}
}

export async function clearData(): Promise<void> {
  try {
    await AsyncStorage.removeItem(KEY);
  } catch {}
}
