import { Transaction, Budget, Goal, CurrencyCode } from './types';
import { getCategory } from './categories';
import { formatMoney, monthKey, MONTHS } from './format';

export interface Totals { income: number; expense: number; net: number }

export function getTotals(txs: Transaction[]): Totals {
  let income = 0;
  let expense = 0;
  for (const t of txs) {
    if (t.type === 'income') income += t.amount;
    else expense += t.amount;
  }
  return { income, expense, net: income - expense };
}

export function getBalance(txs: Transaction[]): number {
  return getTotals(txs).net;
}

export function getMonthTransactions(txs: Transaction[], ref: Date): Transaction[] {
  const key = monthKey(ref);
  return txs.filter((t) => monthKey(new Date(t.date)) === key);
}

export function getLastMonthTransactions(txs: Transaction[], ref: Date): Transaction[] {
  const d = new Date(ref.getFullYear(), ref.getMonth() - 1, 1);
  return getMonthTransactions(txs, d);
}

export interface CategoryBreakdown {
  categoryId: string;
  total: number;
  count: number;
  pct: number;
}

export function getCategoryBreakdown(txs: Transaction[], type: 'expense' | 'income'): CategoryBreakdown[] {
  const filtered = txs.filter((t) => t.type === type);
  const map = new Map<string, { total: number; count: number }>();
  for (const t of filtered) {
    const cur = map.get(t.categoryId) || { total: 0, count: 0 };
    cur.total += t.amount;
    cur.count += 1;
    map.set(t.categoryId, cur);
  }
  const grand = Array.from(map.values()).reduce((s, v) => s + v.total, 0) || 1;
  return Array.from(map.entries())
    .map(([categoryId, v]) => ({ categoryId, total: v.total, count: v.count, pct: v.total / grand }))
    .sort((a, b) => b.total - a.total);
}

export interface DayPoint {
  day: number;
  label: string;
  total: number;
  isToday: boolean;
}

export function getDailySeries(txs: Transaction[], ref: Date): DayPoint[] {
  const year = ref.getFullYear();
  const month = ref.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();
  const sums = new Array<number>(daysInMonth + 1).fill(0);
  for (const t of txs) {
    const d = new Date(t.date);
    if (d.getFullYear() === year && d.getMonth() === month && t.type === 'expense') {
      sums[d.getDate()] += t.amount;
    }
  }
  const out: DayPoint[] = [];
  for (let d = 1; d <= daysInMonth; d++) {
    out.push({ day: d, label: `${d}`, total: sums[d], isToday: today.getFullYear() === year && today.getMonth() === month && today.getDate() === d });
  }
  return out;
}

export interface WeekPoint {
  label: string;
  total: number;
  isToday: boolean;
}

export function getWeekSeries(txs: Transaction[]): WeekPoint[] {
  const out: WeekPoint[] = [];
  const today = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toDateString();
    const total = txs
      .filter((t) => t.type === 'expense' && new Date(t.date).toDateString() === key)
      .reduce((s, t) => s + t.amount, 0);
    out.push({ label: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'][d.getDay()], total, isToday: i === 0 });
  }
  return out;
}

export interface CumPoint {
  day: number;
  thisMonth: number;
  lastMonth: number;
}

export function getCumulativeSeries(txs: Transaction[], ref: Date): CumPoint[] {
  const year = ref.getFullYear();
  const month = ref.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const lastYear = month === 0 ? year - 1 : year;
  const lastMonth = month === 0 ? 11 : month - 1;
  const daysLast = new Date(lastYear, lastMonth + 1, 0).getDate();
  const sumDay = (y: number, m: number, d: number) =>
    txs
      .filter((t) => {
        const td = new Date(t.date);
        return t.type === 'expense' && td.getFullYear() === y && td.getMonth() === m && td.getDate() === d;
      })
      .reduce((s, t) => s + t.amount, 0);
  let cumThis = 0;
  let cumLast = 0;
  const out: CumPoint[] = [];
  for (let d = 1; d <= daysInMonth; d++) {
    cumThis += sumDay(year, month, d);
    cumLast += d <= daysLast ? sumDay(lastYear, lastMonth, d) : 0;
    out.push({ day: d, thisMonth: cumThis, lastMonth: cumLast });
  }
  return out;
}

export function getTopTransactions(txs: Transaction[], n: number): Transaction[] {
  return [...txs].sort((a, b) => b.amount - a.amount).slice(0, n);
}

export interface Insight {
  id: string;
  icon: string;
  color: string;
  title: string;
  message: string;
}

export function generateInsights(
  txs: Transaction[],
  budgets: Budget[],
  goals: Goal[],
  currency: CurrencyCode,
  ref: Date = new Date()
): Insight[] {
  const insights: Insight[] = [];
  const monthTx = txs.filter((t) => {
    const d = new Date(t.date);
    return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth();
  });
  const lastMonthTx = txs.filter((t) => {
    const d = new Date(t.date);
    const lm = new Date(ref.getFullYear(), ref.getMonth() - 1, 1);
    return d.getFullYear() === lm.getFullYear() && d.getMonth() === lm.getMonth();
  });
  const totals = monthTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const lastTotals = lastMonthTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const income = monthTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  // 1. MoM comparison
  if (lastTotals > 0) {
    const change = ((totals - lastTotals) / lastTotals) * 100;
    insights.push({
      id: 'mom',
      icon: change <= 0 ? 'trending-down' : 'trending-up',
      color: change <= 0 ? '#12D69F' : '#FF6B6B',
      title: change <= 0 ? 'إنفاق أقل من الشهر الماضي' : 'إنفاق أعلى من الشهر الماضي',
      message: `مصروفاتك هذا الشهر ${change <= 0 ? 'أقل' : 'أعلى'} بنسبة ${Math.abs(change).toFixed(0)}% عن الشهر الماضي (${Math.round(lastTotals).toLocaleString('en-US')} ${'ج.م'})`,
    });
  }

  // 2. Top category
  const byCat = new Map<string, number>();
  for (const t of monthTx) {
    if (t.type === 'expense') byCat.set(t.categoryId, (byCat.get(t.categoryId) || 0) + t.amount);
  }
  const topCat = Array.from(byCat.entries()).sort((a, b) => b[1] - a[1])[0];
  if (topCat && totals > 0) {
    const cat = require('./categories').getCategory(topCat[0]);
    insights.push({
      id: 'topcat',
      icon: cat.icon,
      color: cat.color,
      title: `أعلى فئة: ${cat.name}`,
      message: `أنفقت ${Math.round(topCat[1]).toLocaleString('en-US')} ج.م على ${cat.name} أي ${((topCat[1] / totals) * 100).toFixed(0)}% من إجمالي مصروفاتك`,
    });
  }

  // 3. Daily average
  const daysSoFar = ref.getDate();
  if (totals > 0) {
    insights.push({
      id: 'avg',
      icon: 'speedometer',
      color: '#5B9DFF',
      title: 'متوسط الإنفاق اليومي',
      message: `متوسط ما تنفقه يومياً هذا الشهر ${Math.round(totals / daysSoFar).toLocaleString('en-US')} ج.م عبر ${monthTx.filter((t) => t.type === 'expense').length} معاملة`,
    });
  }

  // 4. Budget pacing
  const overall = budgets.find((b) => b.categoryId === 'overall');
  if (overall && totals > 0) {
    const pct = (totals / overall.limit) * 100;
    const daysInMonth = new Date(ref.getFullYear(), ref.getMonth() + 1, 0).getDate();
    const expectedPct = (daysSoFar / daysInMonth) * 100;
    insights.push({
      id: 'budget',
      icon: pct > expectedPct + 10 ? 'warning' : 'shield-checkmark',
      color: pct > expectedPct + 10 ? '#FF6B6B' : '#12D69F',
      title: pct > expectedPct + 10 ? 'إنفاق أسرع من المعتاد' : 'ميزانيتك تحت السيطرة',
      message: pct > expectedPct + 10
        ? `استهلكت ${pct.toFixed(0)}% من ميزانيتك الشهرية وأنت في يوم ${daysSoFar} فقط — خفف الإنفاق عشان تخلص الشهر مريح`
        : `استهلكت ${pct.toFixed(0)}% من ميزانيتك الشهرية حتى الآن — أداء ممتاز`,
    });
  }

  // 5. Savings rate
  if (income > 0) {
    const rate = ((income - totals) / income) * 100;
    insights.push({
      id: 'savings',
      icon: 'piggy-bank',
      color: '#F6C445',
      title: 'نسبة الادخار',
      message: `نسبة ادخارك هذا الشهر ${rate.toFixed(0)}% — ${rate >= 20 ? 'ممتاز، استمر!' : rate >= 10 ? 'جيد، ممكن تزيد شوية' : 'حاول توفر أكتر لو تقدر'}`,
    });
  }

  // 6. Biggest transaction
  const biggest = monthTx.filter((t) => t.type === 'expense').sort((a, b) => b.amount - a.amount)[0];
  if (biggest) {
    const cat = require('./categories').getCategory(biggest.categoryId);
    insights.push({
      id: 'biggest',
      icon: cat.icon,
      color: cat.color,
      title: 'أكبر معاملة هذا الشهر',
      message: `${biggest.note || cat.name} بـ ${Math.round(biggest.amount).toLocaleString('en-US')} ج.م في ${new Date(biggest.date).getDate()} ${require('./format').MONTHS[new Date(biggest.date).getMonth()]}`,
    });
  }

  // 7. Goal progress
  for (const g of goals.slice(0, 1)) {
    const pct = Math.min(100, (g.saved / g.target) * 100);
    insights.push({
      id: `goal-${g.id}`,
      icon: 'flag',
      color: g.color,
      title: `هدف: ${g.name}`,
      message: `اكتمل ${pct.toFixed(0)}% من هدفك — فاضل ${Math.round(g.target - g.saved).toLocaleString('en-US')} ج.م ويوصله`,
    });
  }

  return insights;
}
