export type TransactionType = 'expense' | 'income';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  note: string;
  date: string; // ISO string
  recurringId?: string;
  createdAt: number;
}

export interface Budget {
  id: string;
  categoryId: string; // 'overall' for total monthly budget
  limit: number;
}

export interface Goal {
  id: string;
  name: string;
  target: number;
  saved: number;
  color: string;
  icon: string;
  createdAt: number;
}

export type RecurringFrequency = 'daily' | 'weekly' | 'monthly';

export interface RecurringTemplate {
  id: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  note: string;
  frequency: RecurringFrequency;
  nextDate: string; // ISO
  active: boolean;
}

export type CurrencyCode = 'EGP' | 'SAR' | 'AED' | 'KWD' | 'QAR' | 'JOD' | 'USD';

export interface Settings {
  name: string;
  currency: CurrencyCode;
  theme: 'dark' | 'light';
  tts: boolean;
  haptics: boolean;
  budgetOverall: number;
}

export interface AppData {
  transactions: Transaction[];
  budgets: Budget[];
  goals: Goal[];
  recurring: RecurringTemplate[];
  settings: Settings;
}
