import { CurrencyCode } from './types';

export const CURRENCIES: Record<CurrencyCode, { symbol: string; name: string; code: string }> = {
  EGP: { symbol: 'ج.م', name: 'جنيه مصري', code: 'EGP' },
  SAR: { symbol: 'ر.س', name: 'ريال سعودي', code: 'SAR' },
  AED: { symbol: 'د.إ', name: 'درهم إماراتي', code: 'AED' },
  KWD: { symbol: 'د.ك', name: 'دينار كويتي', code: 'KWD' },
  QAR: { symbol: 'ر.ق', name: 'ريال قطري', code: 'QAR' },
  JOD: { symbol: 'د.أ', name: 'دينار أردني', code: 'JOD' },
  USD: { symbol: '$', name: 'دولار أمريكي', code: 'USD' },
};

export function formatMoney(amount: number, currency: CurrencyCode, withSymbol = true): string {
  const abs = Math.abs(amount);
  const str = abs.toLocaleString('en-US', {
    minimumFractionDigits: abs % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });
  if (!withSymbol) return str;
  return `${str} ${CURRENCIES[currency].symbol}`;
}

export function compactMoney(amount: number, currency: CurrencyCode): string {
  const { symbol } = CURRENCIES[currency];
  if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M ${symbol}`;
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)}k ${symbol}`;
  return `${Math.round(amount)} ${symbol}`;
}

export const WEEKDAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
export const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

export function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export function isToday(d: Date): boolean {
  return isSameDay(d, new Date());
}

export function isYesterday(d: Date): boolean {
  const y = new Date();
  y.setDate(y.getDate() - 1);
  return isSameDay(d, y);
}

export function formatDateLabel(iso: string): string {
  const d = new Date(iso);
  if (isToday(d)) return 'اليوم';
  if (isYesterday(d)) return 'أمس';
  return `${d.getDate()} ${MONTHS[d.getMonth()]}${d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : ''}`;
}

export function formatTime(iso: string): string {
  const d = new Date(iso);
  let h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, '0');
  const suffix = h >= 12 ? 'م' : 'ص';
  h = h % 12 || 12;
  return `${h}:${m} ${suffix}`;
}

export function formatFullDate(iso: string): string {
  const d = new Date(iso);
  return `${WEEKDAYS[d.getDay()]}، ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function formatMonthYear(d: Date): string {
  return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function monthKey(d: Date): string {
  return `${d.getFullYear()}-${d.getMonth()}`;
}

export function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'صباح الخير';
  if (h < 18) return 'مساء الخير';
  return 'مساء النور';
}
