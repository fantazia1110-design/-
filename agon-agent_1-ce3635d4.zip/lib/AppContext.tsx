import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { AppData, Transaction, Budget, Goal, RecurringTemplate, Settings, TransactionType, RecurringFrequency } from './types';
import { loadData, saveData, clearData } from './storage';
import { darkTheme, lightTheme, Theme } from './theme';
import { getCategory } from './categories';
import * as Speech from 'expo-speech';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

interface AppContextType {
  data: AppData;
  theme: Theme;
  hydrated: boolean;
  addTransaction: (tx: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransaction: (id: string, patch: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addBudget: (b: Omit<Budget, 'id'>) => void;
  updateBudget: (id: string, patch: Partial<Budget>) => void;
  deleteBudget: (id: string) => void;
  addGoal: (g: Omit<Goal, 'id' | 'createdAt'>) => void;
  updateGoal: (id: string, patch: Partial<Goal>) => void;
  deleteGoal: (id: string) => void;
  addRecurring: (r: Omit<RecurringTemplate, 'id'>) => void;
  updateRecurring: (id: string, patch: Partial<RecurringTemplate>) => void;
  deleteRecurring: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  resetAll: () => void;
  speak: (text: string) => void;
  haptic: (style?: 'light' | 'medium' | 'success') => void;
}

const AppContext = createContext<AppContextType | null>(null);

function uid(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

// ---------- Seed data ----------
function buildSeedData(): AppData {
  const now = new Date();
  const txs: Transaction[] = [];
  let sid = 1;
  const push = (type: TransactionType, amount: number, categoryId: string, note: string, daysAgo: number, hour = 12) => {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    d.setHours(hour, Math.floor(Math.random() * 55), 0, 0);
    txs.push({ id: `seed-${sid++}`, type, amount, categoryId, note, date: d.toISOString(), createdAt: d.getTime() });
  };

  // Salary
  const firstThis = new Date(now.getFullYear(), now.getMonth(), 1, 9);
  txs.push({ id: `seed-${sid++}`, type: 'income', amount: 15000, categoryId: 'salary', note: 'راتب شهري', date: firstThis.toISOString(), createdAt: firstThis.getTime() });
  const firstLast = new Date(now.getFullYear(), now.getMonth() - 1, 1, 9);
  txs.push({ id: `seed-${sid++}`, type: 'income', amount: 15000, categoryId: 'salary', note: 'راتب شهري', date: firstLast.toISOString(), createdAt: firstLast.getTime() });
  push('income', 2400, 'freelance', 'مشروع تصميم متجر', 18, 16);
  push('income', 1800, 'freelance', 'مهمة ترجمة', 42, 15);

  const samples: { cat: string; notes: string[]; min: number; max: number }[] = [
    { cat: 'food', notes: ['غداء عمل مع الزملاء', 'عشاء عائلي', 'قهوة الصباح', 'برجر', 'كشري', 'فطار بالعافية', 'شاورما'], min: 25, max: 380 },
    { cat: 'groceries', notes: ['مشتريات الأسبوع', 'سوبرماركت', 'خضار وفواكه', 'مكتبة البقالة'], min: 120, max: 850 },
    { cat: 'transport', notes: ['أوبر للمكتب', 'كريم', 'بنزين', 'مترو', 'ميكروباص'], min: 20, max: 260 },
    { cat: 'bills', notes: ['فاتورة الكهرباء', 'فاتورة الانترنت', 'فاتورة الموبايل', 'شحن كارت'], min: 60, max: 650 },
    { cat: 'shopping', notes: ['ملابس', 'حذاء جديد', 'عطر', 'نظارة شمسية'], min: 250, max: 2400 },
    { cat: 'health', notes: ['دواء من الصيدلية', 'كشف دكتور', 'تحاليل'], min: 80, max: 620 },
    { cat: 'entertainment', notes: ['سينما', 'اشتراك نتفليكس', 'ألعاب', 'كورة مع الأصحاب'], min: 60, max: 420 },
    { cat: 'education', notes: ['كورس برمجة', 'كتب', 'دروس خصوصية'], min: 150, max: 1400 },
    { cat: 'travel', notes: ['حجز فندق', 'تذكرة طيران'], min: 900, max: 4200 },
    { cat: 'gifts', notes: ['هدية عيد ميلاد', 'هدية شكر'], min: 200, max: 900 },
    { cat: 'subscriptions', notes: ['اشتراك سبوتيفاي', 'اشتراك الشاهد'], min: 50, max: 220 },
  ];

  for (let d = 0; d < 62; d++) {
    const r = Math.random();
    const count = r < 0.22 ? 0 : r < 0.72 ? 1 : 2;
    for (let i = 0; i < count; i++) {
      const s = samples[Math.floor(Math.random() * samples.length)];
      const amount = Math.round((s.min + Math.random() * (s.max - s.min)) / 5) * 5;
      const note = s.notes[Math.floor(Math.random() * s.notes.length)];
      const hour = 8 + Math.floor(Math.random() * 14);
      push('expense', amount, s.cat, note, d, hour);
    }
  }
  // Notable fixed ones
  push('expense', 3000, 'housing', 'إيجار الشقة', 5, 10);
  push('expense', 3000, 'housing', 'إيجار الشقة', 35, 10);
  push('expense', 120, 'subscriptions', 'اشتراك نتفليكس', 8, 20);
  push('expense', 2200, 'shopping', 'ملابس موسم الصيف', 12, 17);
  push('expense', 650, 'health', 'كشف دكتور أسنان', 22, 13);

  txs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return {
    transactions: txs,
    budgets: [
      { id: 'b-overall', categoryId: 'overall', limit: 18000 },
      { id: 'b-food', categoryId: 'food', limit: 2500 },
      { id: 'b-transport', categoryId: 'transport', limit: 1200 },
      { id: 'b-shopping', categoryId: 'shopping', limit: 2000 },
      { id: 'b-bills', categoryId: 'bills', limit: 1500 },
    ],
    goals: [
      { id: 'g1', name: 'سفر إلى إيطاليا', target: 30000, saved: 12500, color: '#5B9DFF', icon: 'airplane', createdAt: Date.now() - 86400000 * 30 },
      { id: 'g2', name: 'صندوق الطوارئ', target: 50000, saved: 21000, color: '#F6C445', icon: 'shield', createdAt: Date.now() - 86400000 * 60 },
    ],
    recurring: [
      { id: 'r1', type: 'expense', amount: 3000, categoryId: 'housing', note: 'إيجار الشقة', frequency: 'monthly', nextDate: new Date(now.getFullYear(), now.getMonth() + 1, 1, 10).toISOString(), active: true },
      { id: 'r2', type: 'expense', amount: 120, categoryId: 'subscriptions', note: 'اشتراك نتفليكس', frequency: 'monthly', nextDate: new Date(now.getFullYear(), now.getMonth() + 1, 8, 20).toISOString(), active: true },
    ],
    settings: {
      name: 'أحمد',
      currency: 'EGP',
      theme: 'light',
      tts: true,
      haptics: true,
      budgetOverall: 18000,
    },
  };
}

function processRecurring(data: AppData): AppData {
  const now = Date.now();
  let changed = false;
  const newTxs = [...data.transactions];
  const recurring = data.recurring.map((r) => {
    if (!r.active) return r;
    let next = new Date(r.nextDate);
    let guard = 0;
    while (next.getTime() <= now && guard < 12) {
      newTxs.push({
        id: `auto-${r.id}-${next.getTime()}`,
        type: r.type,
        amount: r.amount,
        categoryId: r.categoryId,
        note: `${r.note} (تلقائي)`,
        date: next.toISOString(),
        recurringId: r.id,
        createdAt: next.getTime(),
      });
      const advanced = new Date(next);
      if (r.frequency === 'daily') advanced.setDate(advanced.getDate() + 1);
      else if (r.frequency === 'weekly') advanced.setDate(advanced.getDate() + 7);
      else advanced.setMonth(advanced.getMonth() + 1);
      next = advanced;
      guard++;
      changed = true;
    }
    return { ...r, nextDate: next.toISOString() };
  });
  if (!changed) return data;
  const transactions = [...newTxs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  return { ...data, transactions, recurring };
}

// ---------- Provider ----------
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData | null>(null);

  useEffect(() => {
    (async () => {
      const stored = await loadData();
      let initial = stored || buildSeedData();
      initial = processRecurring(initial);
      setData(initial);
    })();
  }, []);

  useEffect(() => {
    if (data) saveData(data);
  }, [data]);

  const update = useCallback((fn: (d: AppData) => AppData) => {
    setData((prev) => (prev ? fn(prev) : prev));
  }, []);

  const value = useMemo<AppContextType | null>(() => {
    if (!data) return null;
    const theme = data.settings.theme === 'dark' ? darkTheme : lightTheme;
    return {
      data,
      theme,
      hydrated: true,
      addTransaction: (tx) =>
        update((d) => ({
          ...d,
          transactions: [{ ...tx, id: uid(), createdAt: Date.now() }, ...d.transactions],
        })),
      updateTransaction: (id, patch) =>
        update((d) => ({ ...d, transactions: d.transactions.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
      deleteTransaction: (id) =>
        update((d) => ({ ...d, transactions: d.transactions.filter((t) => t.id !== id) })),
      addBudget: (b) => update((d) => ({ ...d, budgets: [...d.budgets, { ...b, id: uid() }] })),
      updateBudget: (id, patch) =>
        update((d) => ({ ...d, budgets: d.budgets.map((b) => (b.id === id ? { ...b, ...patch } : b)) })),
      deleteBudget: (id) => update((d) => ({ ...d, budgets: d.budgets.filter((b) => b.id !== id) })),
      addGoal: (g) => update((d) => ({ ...d, goals: [{ ...g, id: uid(), createdAt: Date.now() }, ...d.goals] })),
      updateGoal: (id, patch) =>
        update((d) => ({ ...d, goals: d.goals.map((g) => (g.id === id ? { ...g, ...patch } : g)) })),
      deleteGoal: (id) => update((d) => ({ ...d, goals: d.goals.filter((g) => g.id !== id) })),
      addRecurring: (r) => update((d) => ({ ...d, recurring: [{ ...r, id: uid() }, ...d.recurring] })),
      updateRecurring: (id, patch) =>
        update((d) => ({ ...d, recurring: d.recurring.map((r) => (r.id === id ? { ...r, ...patch } : r)) })),
      deleteRecurring: (id) => update((d) => ({ ...d, recurring: d.recurring.filter((r) => r.id !== id) })),
      updateSettings: (patch) => update((d) => ({ ...d, settings: { ...d.settings, ...patch } })),
      resetAll: () => {
        clearData();
        setData(buildSeedData());
      },
      speak: (text) => {
        if (!data.settings.tts) return;
        try {
          Speech.stop();
          Speech.speak(text, { language: 'ar-SA', rate: 0.95 });
        } catch {}
      },
      haptic: (style = 'light') => {
        if (!data.settings.haptics || Platform.OS === 'web') return;
        try {
          if (style === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          else if (style === 'medium') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        } catch {}
      },
    };
  }, [data, update]);

  if (!value) return null;
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextType {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
