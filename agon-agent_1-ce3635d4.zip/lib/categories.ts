import { Ionicons } from '@expo/vector-icons';

export interface Category {
  id: string;
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  type: 'expense' | 'income';
  keywords: string[];
}

export const EXPENSE_CATEGORIES: Category[] = [
  { id: 'food', name: 'طعام ومطاعم', icon: 'restaurant', color: '#FF8A5C', type: 'expense', keywords: ['طعام', 'مطعم', 'غداء', 'عشاء', 'فطار', 'افطار', 'وجبة', 'وجبه', 'برجر', 'بيتزا', 'قهوة', 'قهوه', 'كافيه', 'كافي', 'حلويات', 'حلو', 'كشري', 'شاورما', 'فول', 'طعمية', 'اكل', 'اكلات', 'عيش', 'خبز', 'دونات', 'شاي', 'عصير', 'ريستورون', 'وجبات', 'سناك', 'حلا', 'آيس كريم', 'ايس كريم', 'فول', 'طعميه'] },
  { id: 'groceries', name: 'مشتريات', icon: 'cart', color: '#4ADE80', type: 'expense', keywords: ['سوبرماركت', 'سوبر ماركت', 'بقاله', 'بقالة', 'مشتريات', 'خضار', 'خضره', 'لحوم', 'لحم', 'فاكيه', 'فاكهة', 'ماركت', 'جبن', 'حليب', 'بيض', 'ارز', 'مكرونه', 'مكرونة', 'شيبسي', 'مشروبات', 'خضرا', 'جامعه', 'سوبر'] },
  { id: 'transport', name: 'مواصلات', icon: 'car', color: '#5B9DFF', type: 'expense', keywords: ['اوبر', 'أوبر', 'كريم', 'تاكسي', 'مواصلات', 'مترو', 'بنزين', 'وقود', 'باص', 'بص', 'ميكروباص', 'جراب', 'قطار', 'ترام', 'مونوريل', 'سياره', 'سيارة', 'توصيل', 'سائق', 'اجرة'] },
  { id: 'shopping', name: 'تسوق', icon: 'bag-handle', color: '#F472B6', type: 'expense', keywords: ['ملابس', 'شنطة', 'حذاء', 'تسوق', 'مول', 'عطور', 'عطر', 'ساعات', 'ساعه', 'ساعة', 'اكسسوار', 'نظارة', 'نظارات', 'مكياج', 'عنايه', 'عناية', 'بشره', 'بشرة', 'شعر', 'حلاقه', 'حلاقة', 'حلاق', 'كوتش', 'حقيبه', 'حقيبة', 'جيم', 'عضويه', 'عضوية'] },
  { id: 'bills', name: 'فواتير', icon: 'document-text', color: '#FACC15', type: 'expense', keywords: ['فاتوره', 'فاتورة', 'فواتير', 'كهرباء', 'كهربه', 'ماء', 'انترنت', 'تليفون', 'موبايل', 'خط', 'غاز', 'صيانه', 'صيانة', 'تصليح', 'سباكه', 'سباكة', 'شحن', 'كارت', 'فودافون', 'اورانج', 'اتصالات', 'مين', 'برميل'] },
  { id: 'health', name: 'صحة', icon: 'medkit', color: '#FB7185', type: 'expense', keywords: ['دواء', 'دوا', 'صيدليه', 'صيدلية', 'طبيب', 'أسنان', 'اسنان', 'عياده', 'عيادة', 'مستشفى', 'تحاليل', 'أشعه', 'أشعة', 'اشعه', 'فيتامين', 'مكملات', 'علاج', 'كشف', 'دكتور'] },
  { id: 'entertainment', name: 'ترفيه', icon: 'game-controller', color: '#A78BFA', type: 'expense', keywords: ['سينما', 'مسرح', 'العاب', 'العب', 'لعب', 'نتفليكس', 'ملاهي', 'حديقه', 'حديقة', 'كوره', 'ماتش', 'تذكره', 'تذكرة', 'حفله', 'حفلة', 'كونسرت', 'مطرب', 'ديسكور', 'شاشات', 'قاهره', 'قاهرة'] },
  { id: 'education', name: 'تعليم', icon: 'school', color: '#38BDF8', type: 'expense', keywords: ['كورس', 'دوره', 'دورة', 'كتاب', 'تعليم', 'مدرسه', 'مدرسة', 'جامعه', 'جامعة', 'امتحان', 'امتحانات', 'تدريب', 'دروس', 'شهاده', 'شهادة', 'مدرس خصوصي', 'مكتبه', 'مكتبة'] },
  { id: 'travel', name: 'سفر', icon: 'airplane', color: '#2DD4BF', type: 'expense', keywords: ['سفر', 'فندق', 'طيران', 'تذكره', 'تذكرة', 'رحله', 'رحلة', 'مطار', 'طائره', 'طائرة', 'إقامه', 'إقامة', 'اقامه', 'حجز', 'سكه حديد'] },
  { id: 'housing', name: 'سكن وإيجار', icon: 'home', color: '#FB923C', type: 'expense', keywords: ['إيجار', 'ايجار', 'سكن', 'شقه', 'شقة', 'تمليك', 'قسط', 'ايجار الشقه', 'إيجار الشقة'] },
  { id: 'gifts', name: 'هدايا', icon: 'gift', color: '#F472B6', type: 'expense', keywords: ['هديه', 'هدية', 'هدايا', 'عيد ميلاد', 'مناسبه', 'مناسبة', 'مناسبات', 'عرس', 'فرح', 'كشف حساب', 'عيديه', 'عيدية'] },
  { id: 'subscriptions', name: 'اشتراكات', icon: 'repeat', color: '#818CF8', type: 'expense', keywords: ['اشتراك', 'اشتراكات', 'نتفليكس', 'شاهد', 'يوتيوب', 'سبوتيفاي', 'اب ستور', 'آب ستور', 'جوجل', 'اي كلاود', 'آيكلاود', 'برايم'] },
  { id: 'other_expense', name: 'أخرى', icon: 'ellipsis-horizontal', color: '#94A3B8', type: 'expense', keywords: ['أخرى', 'اخرى', 'مصروف', 'مصاريف', 'نفقه', 'نفقة', 'حاجه', 'حاجة'] },
];

export const INCOME_CATEGORIES: Category[] = [
  { id: 'salary', name: 'راتب', icon: 'briefcase', color: '#10D9A0', type: 'income', keywords: ['راتب', 'مرتب', 'راتبي', 'مرتبي', 'شهريه', 'شهرية'] },
  { id: 'freelance', name: 'عمل حر', icon: 'laptop', color: '#34D399', type: 'income', keywords: ['عمل حر', 'فريلانس', 'فريلنس', 'مشروع حر', 'مهمه', 'مهمة'] },
  { id: 'business', name: 'أعمال', icon: 'storefront', color: '#6EE7B7', type: 'income', keywords: ['أعمال', 'اعمال', 'بيع', 'مبيعات', 'متجر', 'محل'] },
  { id: 'investment', name: 'استثمار', icon: 'trending-up', color: '#F5B942', type: 'income', keywords: ['أرباح', 'ارباح', 'استثمار', 'عائد', 'فلوس', 'ربح', 'مكسب'] },
  { id: 'gift_income', name: 'هدايا ومكافآت', icon: 'gift', color: '#F472B6', type: 'income', keywords: ['مكافأه', 'مكافأة', 'هديه', 'هدية', 'هدايا', 'عيديه', 'عيدية', 'بونص', 'بونس'] },
  { id: 'other_income', name: 'أخرى', icon: 'ellipsis-horizontal', color: '#94A3B8', type: 'income', keywords: ['دخل', 'أخرى', 'اخرى', 'تحويل', 'استلام', 'فلوس دخلت'] },
];

export const ALL_CATEGORIES: Category[] = [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES];

export function getCategory(id: string): Category {
  return ALL_CATEGORIES.find((c) => c.id === id) || EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
}

export function getExpenseCategories(): Category[] {
  return EXPENSE_CATEGORIES;
}

export function getIncomeCategories(): Category[] {
  return INCOME_CATEGORIES;
}
