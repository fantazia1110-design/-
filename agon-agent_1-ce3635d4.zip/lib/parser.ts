import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, Category } from './categories';

export interface ParsedTransaction {
  type: 'expense' | 'income';
  amount: number | null;
  categoryId: string | null;
  date: Date;
  note: string;
  issues: string[];
}

const EXPENSE_WORDS = ['صرفت', 'صرف', 'دفعت', 'دفع', 'انفقت', 'انفق', 'اشتريت', 'شراء', 'خرج', 'خرجت', 'كلفت', 'كلف', 'تكلفه', 'تكلفة', 'مصروف', 'مصاريف', 'سحبت', 'سحب', 'نزل', 'حرق', 'شرائيه', 'شرائية', 'دفعتها', 'صرفتها'];
const INCOME_WORDS = ['دخل', 'دخلني', 'دخلت', 'استلمت', 'استلام', 'راتب', 'راتبي', 'مرتب', 'مرتبي', 'مكافأه', 'مكافأة', 'أرباح', 'ارباح', 'ربح', 'بيع', 'تحويل', 'وصلني', 'عائد', 'فلوس', 'مكسب', 'بونص', 'بونس', 'عائد شهري'];
const CURRENCY_WORDS = ['جنيه', 'جنيهات', 'ج.م', 'ريال', 'ر.س', 'درهم', 'د.إ', 'دينار', 'د.ك', 'دولار', 'دولارات', '$', 'يورو', 'ليره', 'ليرة', 'جنيه مصري'];

function normalize(s: string): string {
  return s
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[َ-ْ]/g, '')
    .replace(/[\u0660-\u0669]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 0x0660 + 0x30))
    .replace(/,/g, '.')
    .trim();
}

const normalizedExpenseKeywords: { id: string; kw: string[] }[] = EXPENSE_CATEGORIES.map((c) => ({ id: c.id, kw: c.keywords.map(normalize) }));
const normalizedIncomeKeywords: { id: string; kw: string[] }[] = INCOME_CATEGORIES.map((c) => ({ id: c.id, kw: c.keywords.map(normalize) }));

function detectCategory(text: string, type: 'expense' | 'income'): string | null {
  const pools = type === 'expense' ? normalizedExpenseKeywords : normalizedIncomeKeywords;
  let best: string | null = null;
  let bestLen = 0;
  for (const pool of pools) {
    for (const kw of pool.kw) {
      if (kw.length >= 2 && text.includes(kw) && kw.length > bestLen) {
        best = pool.id;
        bestLen = kw.length;
      }
    }
  }
  return best;
}

function detectType(text: string): 'expense' | 'income' {
  const hasExpense = EXPENSE_WORDS.some((w) => text.includes(normalize(w)));
  const hasIncome = INCOME_WORDS.some((w) => text.includes(normalize(w)));
  if (hasIncome && !hasExpense) return 'income';
  return 'expense';
}

function detectAmount(text: string): number | null {
  const m = text.match(/(\d+(?:\.\d+)?)\s*(مليون|الف|الفين)?/);
  if (!m) return null;
  let amount = parseFloat(m[1]);
  const mult = m[2];
  if (mult) {
    if (mult.includes('مليون')) amount *= 1000000;
    else amount *= 1000;
  }
  return Math.round(amount * 100) / 100;
}

function detectDate(text: string): Date {
  const now = new Date();
  if (/قبل (\d+) يوم/.test(text)) {
    const n = parseInt(text.match(/قبل (\d+) يوم/)![1], 10);
    const d = new Date(now);
    d.setDate(d.getDate() - n);
    return d;
  }
  if (/قبل يومين/.test(text)) {
    const d = new Date(now);
    d.setDate(d.getDate() - 2);
    return d;
  }
  if (/امس|امبارح|بارح/.test(text)) {
    const d = new Date(now);
    d.setDate(d.getDate() - 1);
    return d;
  }
  if (/اول الشهر|أول الشهر/.test(text)) {
    return new Date(now.getFullYear(), now.getMonth(), 1, now.getHours());
  }
  if (/الاسبوع اللي فات|الاسبوع اللي فات/.test(text)) {
    const d = new Date(now);
    d.setDate(d.getDate() - 7);
    return d;
  }
  if (/الشهر اللي فات/.test(text)) {
    const d = new Date(now);
    d.setMonth(d.getMonth() - 1);
    return d;
  }
  return now;
}

function buildNote(raw: string, parsed: { amount: number | null; categoryId: string | null; type: 'expense' | 'income' }): string {
  let t = raw;
  // remove amount + currency
  t = t.replace(/\d+(?:\.\d+)?\s*(مليون|الف|الفين)?/g, ' ');
  for (const w of CURRENCY_WORDS) t = t.split(w).join(' ');
  const typeWords = [...EXPENSE_WORDS, ...INCOME_WORDS];
  for (const w of typeWords) {
    const nw = normalize(w);
    if (t.includes(w)) t = t.split(w).join(' ');
    else if (t.includes(nw)) t = t.split(nw).join(' ');
  }
  for (const w of ['اليوم', 'امس', 'أمس', 'امبارح', 'بارح', 'قبل يومين', 'قبل', 'يوم', 'ايام', 'أيام', 'اول الشهر', 'أول الشهر', 'الاسبوع اللي فات', 'الشهر اللي فات', 'على', 'عن', 'في', 'من', 'اللي', 'هذا', 'هذه']) {
    t = t.split(w).join(' ');
  }
  // remove matched category keywords
  const cat = parsed.categoryId;
  if (cat) {
    const pool = [...require('./categories').EXPENSE_CATEGORIES, ...require('./categories').INCOME_CATEGORIES] as { id: string; keywords: string[] }[];
    const c = pool.find((x) => x.id === cat);
    if (c) {
      for (const kw of c.keywords) {
        t = t.split(kw).join(' ');
        const nkw = normalize(kw);
        t = t.split(nkw).join(' ');
      }
    }
  }
  return t.replace(/\s+/g, ' ').trim();
}

export function parseText(input: string): ParsedTransaction {
  const raw = input.trim();
  const text = normalize(raw);
  const type = detectType(text);
  const amount = detectAmount(text);
  const categoryId = detectCategory(text, type);
  const date = detectDate(text);
  const issues: string[] = [];
  if (!amount) issues.push('لم يتم تحديد المبلغ — أضف رقماً مثل "50"');
  if (!categoryId) issues.push('لم يتم تحديد الفئة — اذكر مثل "طعام" أو "مواصلات"');
  const note = buildNote(raw, { amount, categoryId, type }) || (categoryId ? '' : 'معاملة');
  return { type, amount, categoryId, date, note, issues };
}

export const SAMPLE_PHRASES = [
  'صرفت 50 جنيه على الغداء',
  'أوبر 45 جنيه',
  'فاتورة الكهرباء 320',
  'استلمت الراتب 15000 جنيه',
  'مشيت مطعم وصرفت 120',
  'اشتريت ملابس 800 جنيه',
  'كورس برمجة 1500',
  'سوبرماركت 430 جنيه',
];
