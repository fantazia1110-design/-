export interface Theme {
  dark: boolean;
  bg: string;
  bgSecondary: string;
  card: string;
  cardAlt: string;
  border: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  primary: string;
  primaryDeep: string;
  primarySoft: string;
  onPrimary: string;
  success: string;
  successSoft: string;
  danger: string;
  dangerSoft: string;
  gold: string;
  goldSoft: string;
  blue: string;
  purple: string;
  tabBar: string;
  inputBg: string;
  shadow: string;
  chartTrack: string;
  grad: { primary: string[]; danger: string[]; success: string[]; gold: string[] };
}

// Light theme — exact reference palette
export const lightTheme: Theme = {
  dark: false,
  bg: '#F7F6F9',
  bgSecondary: '#F1EFF6',
  card: '#FFFFFF',
  cardAlt: '#F7F6F9',
  border: '#E9E6ED',
  text: '#1A1A1A',
  textSecondary: '#6B6B76',
  textMuted: '#9B9BA6',
  primary: '#5A2D91',
  primaryDeep: '#4B2679',
  primarySoft: 'rgba(90,45,145,0.10)',
  onPrimary: '#FFFFFF',
  success: '#16A34A',
  successSoft: 'rgba(22,163,74,0.12)',
  danger: '#FF3B30',
  dangerSoft: 'rgba(255,59,48,0.10)',
  gold: '#FF6A13',
  goldSoft: 'rgba(255,106,19,0.12)',
  blue: '#0467A3',
  purple: '#894C9A',
  tabBar: '#FFFFFF',
  inputBg: '#F4F2F8',
  shadow: '#5A2D91',
  chartTrack: '#EFEBF5',
  grad: {
    primary: ['#5A2D91', '#4B2679', '#3E2063'],
    danger: ['#FF3B30', '#D62D25'],
    success: ['#16A34A', '#0E7A36'],
    gold: ['#FF6A13', '#E05500'],
  },
};

// Dark theme — purple-accented dark
export const darkTheme: Theme = {
  dark: true,
  bg: '#120E1A',
  bgSecondary: '#171224',
  card: '#1E1730',
  cardAlt: '#251C3A',
  border: '#332A4A',
  text: '#F4F2FA',
  textSecondary: '#A79FBD',
  textMuted: '#6E6588',
  primary: '#A97FE8',
  primaryDeep: '#894C9A',
  primarySoft: 'rgba(169,127,232,0.16)',
  onPrimary: '#1A0E2E',
  success: '#22C55E',
  successSoft: 'rgba(34,197,94,0.16)',
  danger: '#FF5A50',
  dangerSoft: 'rgba(255,90,80,0.16)',
  gold: '#FF8A3D',
  goldSoft: 'rgba(255,138,61,0.16)',
  blue: '#4A90E2',
  purple: '#C4A1E8',
  tabBar: '#171224',
  inputBg: '#251C3A',
  shadow: '#000000',
  chartTrack: '#2A2140',
  grad: {
    primary: ['#A97FE8', '#894C9A', '#6B3A8F'],
    danger: ['#FF5A50', '#D63A30'],
    success: ['#22C55E', '#16A34A'],
    gold: ['#FF8A3D', '#E05500'],
  },
};
