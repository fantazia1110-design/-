import 'react-native-gesture-handler';
import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, Platform, I18nManager } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useFonts, Cairo_400Regular, Cairo_600SemiBold, Cairo_700Bold, Cairo_800ExtraBold, Cairo_900Black } from '@expo-google-fonts/cairo';

import { AppProvider, useApp } from './lib/AppContext';
import HomeScreen from './screens/HomeScreen';
import TransactionsScreen from './screens/TransactionsScreen';
import AddTransactionScreen from './screens/AddTransactionScreen';
import AnalyticsScreen from './screens/AnalyticsScreen';
import BudgetsScreen from './screens/BudgetsScreen';
import SettingsScreen from './screens/SettingsScreen';
import TransactionDetailScreen from './screens/TransactionDetailScreen';

// Force RTL for Arabic
if (Platform.OS === 'web' && typeof document !== 'undefined') {
  document.documentElement.dir = 'rtl';
  document.documentElement.lang = 'ar';
}
I18nManager.forceRTL(true);
I18nManager.allowRTL(true);

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TABS = [
  { name: 'HomeTab', label: 'الرئيسية', icon: 'home' as const },
  { name: 'TransactionsTab', label: 'المعاملات', icon: 'receipt' as const },
  { name: 'AddPlaceholder', label: '', icon: 'add' as const },
  { name: 'AnalyticsTab', label: 'التقارير', icon: 'analytics' as const },
  { name: 'BudgetsTab', label: 'الميزانية', icon: 'wallet' as const },
];

function CustomTabBar({ state, navigation }: any) {
  const { theme } = useApp();
  return (
    <View
      style={{
        flexDirection: 'row',
        backgroundColor: theme.tabBar,
        borderTopWidth: 1,
        borderTopColor: theme.border,
        paddingBottom: Platform.OS === 'web' ? 8 : 22,
        paddingTop: 10,
        paddingHorizontal: 8,
      }}
    >
      {state.routes.map((route: any, index: number) => {
        const focused = state.index === index;
        const conf = TABS[index];

        if (route.name === 'AddPlaceholder') {
          return (
            <TouchableOpacity
              key={route.key}
              activeOpacity={0.85}
              onPress={() => navigation.navigate('AddTransaction', {})}
              style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
            >
              <LinearGradient
                colors={[theme.primary, theme.primaryDeep]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  width: 54,
                  height: 54,
                  borderRadius: 20,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginTop: -26,
                  shadowColor: theme.primary,
                  shadowOpacity: 0.45,
                  shadowRadius: 14,
                  shadowOffset: { width: 0, height: 6 },
                  elevation: 10,
                  borderWidth: 4,
                  borderColor: theme.tabBar,
                }}
              >
                <Ionicons name="add" size={30} color="#fff" />
              </LinearGradient>
            </TouchableOpacity>
          );
        }

        const onPress = () => {
          const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
          if (!focused && !event.defaultPrevented) navigation.navigate(route.name);
        };

        return (
          <TouchableOpacity key={route.key} onPress={onPress} activeOpacity={0.7} style={{ flex: 1, alignItems: 'center', paddingVertical: 4 }}>
            <Ionicons name={conf.icon} size={22} color={focused ? theme.primary : theme.textMuted} />
            <Text style={{ color: focused ? theme.primary : theme.textMuted, fontSize: 10.5, fontWeight: '800', marginTop: 3 }}>
              {conf.label}
            </Text>
            {focused ? (
              <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: theme.primary, marginTop: 4 }} />
            ) : (
              <View style={{ height: 8 }} />
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown: false }}
      tabBar={(props) => <CustomTabBar {...props} />}
    >
      <Tab.Screen name="HomeTab" component={HomeScreen} />
      <Tab.Screen name="TransactionsTab" component={TransactionsScreen} />
      <Tab.Screen name="AddPlaceholder" component={View} listeners={({ navigation }) => ({ tabPress: (e) => { e.preventDefault(); navigation.navigate('AddTransaction', {}); } })} />
      <Tab.Screen name="AnalyticsTab" component={AnalyticsScreen} />
      <Tab.Screen name="BudgetsTab" component={BudgetsScreen} />
    </Tab.Navigator>
  );
}

function Splash() {
  return (
    <View style={{ flex: 1, backgroundColor: '#F7F6F9', alignItems: 'center', justifyContent: 'center' }}>
      <LinearGradient
        colors={['#5A2D91', '#4C1973']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ width: 88, height: 88, borderRadius: 28, alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}
      >
        <Ionicons name="wallet" size={42} color="#fff" />
      </LinearGradient>
      <Text style={{ color: '#1A1A1A', fontSize: 28, fontWeight: '900' }}>مصاريفي</Text>
      <Text style={{ color: '#9B9BA6', fontSize: 13, fontWeight: '700', marginTop: 6 }}>تتبع • حلل • ادخر</Text>
    </View>
  );
}

function RootNavigator() {
  const { theme, data } = useApp();
  const navTheme = theme.dark
    ? { ...DarkTheme, colors: { ...DarkTheme.colors, background: theme.bg, card: theme.card, text: theme.text, border: theme.border, primary: theme.primary } }
    : { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: theme.bg, card: theme.card, text: theme.text, border: theme.border, primary: theme.primary } };

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={MainTabs} />
        <Stack.Screen name="AddTransaction" component={AddTransactionScreen} options={{ presentation: 'modal' }} />
        <Stack.Screen name="TransactionDetail" component={TransactionDetailScreen} options={{ presentation: 'modal' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ presentation: 'modal' }} />
      </Stack.Navigator>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />
    </NavigationContainer>
  );
}

function ThemedApp() {
  const { data } = useApp();
  if (!data) return <Splash />;
  return <RootNavigator />;
}

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
    Cairo_400Regular,
    Cairo_600SemiBold,
    Cairo_700Bold,
    Cairo_800ExtraBold,
    Cairo_900Black,
  });

  if (!fontsLoaded) return <Splash />;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AppProvider>
          <ThemedApp />
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
